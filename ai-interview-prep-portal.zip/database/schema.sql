-- MySQL Schema for AI-Based Interview Practice Portal

CREATE DATABASE IF NOT EXISTS interview_practice;
USE interview_practice;

-- 1. Users Table
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  profile_image VARCHAR(500) DEFAULT NULL,
  is_admin BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. Questions Table
CREATE TABLE IF NOT EXISTS questions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  role VARCHAR(100) NOT NULL,              -- e.g., 'Web Developer'
  category VARCHAR(100) NOT NULL,          -- e.g., 'Technical', 'HR', 'Aptitude'
  difficulty VARCHAR(50) NOT NULL,         -- e.g., 'Beginner', 'Intermediate', 'Advanced'
  question TEXT NOT NULL,
  expected_keywords TEXT NOT NULL,        -- Comma-separated keywords
  sample_answer TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 3. Interviews Table
CREATE TABLE IF NOT EXISTS interviews (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  role VARCHAR(100) NOT NULL,
  interview_type VARCHAR(100) NOT NULL,    -- 'Technical', 'HR', 'Mock Placement'
  difficulty VARCHAR(50) NOT NULL,
  date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  overall_score DECIMAL(5,2) DEFAULT 0.00,
  technical_score DECIMAL(5,2) DEFAULT 0.00,
  communication_score DECIMAL(5,2) DEFAULT 0.00,
  confidence_score DECIMAL(5,2) DEFAULT 0.00,
  time_settings INT DEFAULT 60,            -- seconds per question
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- 4. Answers Table (Individual responses to interview questions)
CREATE TABLE IF NOT EXISTS answers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  interview_id INT NOT NULL,
  question_id INT NOT NULL,
  user_answer TEXT NOT NULL,
  time_taken INT DEFAULT 0,                -- seconds
  score INT DEFAULT 0,                     -- score out of 100 for this answer
  technical_accuracy INT DEFAULT 0,
  communication_score INT DEFAULT 0,
  confidence_score INT DEFAULT 0,
  feedback TEXT NOT NULL,                  -- Feedback summary, strengths, weaknesses
  FOREIGN KEY (interview_id) REFERENCES interviews(id) ON DELETE CASCADE,
  FOREIGN KEY (question_id) REFERENCES questions(id) ON DELETE CASCADE
);

-- 5. Results Table (Consolidated Report Cards & Analytics)
CREATE TABLE IF NOT EXISTS results (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  interview_id INT NOT NULL,
  technical_score INT NOT NULL,
  communication_score INT NOT NULL,
  confidence_score INT NOT NULL,
  overall_score INT NOT NULL,
  strengths TEXT NOT NULL,                 -- JSON description or text
  weaknesses TEXT NOT NULL,                -- JSON description or text
  improvement_suggestions TEXT NOT NULL,   -- Suggestions/Recommended track
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (interview_id) REFERENCES interviews(id) ON DELETE CASCADE
);
