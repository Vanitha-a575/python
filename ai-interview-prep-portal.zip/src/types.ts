export interface User {
  id: string;
  name: string;
  email: string;
  password?: string;
  profile_image?: string;
  isAdmin?: boolean;
  created_at: string;
}

export interface Question {
  id: string;
  role: string;          // e.g. 'Web Developer', 'Full Stack Developer', etc.
  category: string;      // 'Technical', 'HR', 'Aptitude'
  difficulty: string;    // 'Beginner', 'Intermediate', 'Advanced'
  question: string;
  expected_keywords: string[];
  sample_answer: string;
}

export interface Interview {
  id: string;
  user_id: string;
  role: string;
  interview_type: string; // 'Technical', 'HR', 'Mock Placement'
  difficulty: string;
  date: string;
  overall_score: number;
  technical_score: number;
  communication_score: number;
  confidence_score: number;
  time_settings: number;  // seconds per question
  mode: 'voice' | 'text';
  questions: Array<Question & {
    userAnswer?: string;
    timeTaken?: number;
    evaluation?: AnswerEvaluation;
  }>;
  status: 'pending' | 'in_progress' | 'completed';
}

export interface AnswerEvaluation {
  score: number;
  technical_score: number;
  communication_score: number;
  confidence_score: number;
  relevance: string;
  technicalAccuracy: string;
  completeness: string;
  communicationQuality: string;
  grammar: string;
  keywordCoverage: {
    covered: string[];
    missed: string[];
    percentage: number;
  };
  strengths: string[];
  weaknesses: string[];
  suggestions: string[];
}

export interface Result {
  id: string;
  user_id: string;
  interview_id: string;
  role: string;
  interview_type: string;
  date: string;
  technical_score: number;
  communication_score: number;
  confidence_score: number;
  overall_score: number;
  strengths: string[];
  weaknesses: string[];
  improvement_suggestions: string[];
  recommended_resources: Array<{
    topic: string;
    description: string;
    resource: string;
  }>;
}

export interface DashboardStats {
  totalInterviews: number;
  averageScore: number;
  bestScore: number;
  weakestCategory: string;
  technicalScore: number;
  communicationScore: number;
  confidenceScore: number;
  recentHistory: Array<{
    id: string;
    role: string;
    date: string;
    overall_score: number;
    interview_type: string;
    questions_count: number;
  }>;
  categoryScores: {
    technical: number;
    hr: number;
    aptitude: number;
  };
  monthlyProgress: Array<{
    month: string;
    score: number;
    count: number;
  }>;
  roleSuccessScores: Array<{
    role: string;
    score: number;
  }>;
}

export interface AdminStats {
  totalUsers: number;
  totalQuestions: number;
  totalInterviews: number;
  averageOverallScore: number;
  roleBreakdown: Record<string, number>;
  categoryBreakdown: Record<string, number>;
  recentInterviews: Array<{
    id: string;
    userName: string;
    userEmail: string;
    role: string;
    date: string;
    score: number;
  }>;
}
