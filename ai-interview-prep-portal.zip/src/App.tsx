import React, { useState, useEffect } from 'react';
import { 
  Briefcase, 
  BookOpen, 
  User as UserIcon, 
  Shield, 
  LogOut, 
  Sun, 
  Moon, 
  Award, 
  BriefcaseIcon,
  ChevronRight,
  Menu,
  GraduationCap
} from 'lucide-react';

import Dashboard from './components/Dashboard';
import PracticeSettings from './components/PracticeSettings';
import LiveArena from './components/LiveArena';
import ReportViewer from './components/ReportViewer';
import Profile from './components/Profile';
import AdminPanel from './components/AdminPanel';

import { User, DashboardStats, Result, AnswerEvaluation } from './types';

export default function App() {
  // Theme State
  const [darkMode, setDarkMode] = useState(false);

  // Authentication State
  const [token, setToken] = useState<string | null>(localStorage.getItem('interview_token'));
  const [user, setUser] = useState<User | null>(null);
  const [authMode, setAuthMode] = useState<'login' | 'register' | 'forgot'>('login');
  const [isLoadingSession, setIsLoadingSession] = useState(true);

  // Layout Sidebar Navigation
  const [activeTab, setActiveTab] = useState<'dashboard' | 'practice' | 'live' | 'report' | 'profile' | 'admin'>('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // Interactive flow states
  const [dashboardStats, setDashboardStats] = useState<DashboardStats | null>(null);
  const [activeInterview, setActiveInterview] = useState<any>(null);
  const [activeReport, setActiveReport] = useState<{ result: Result; interview: any } | null>(null);

  // Authentication Fields
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(false);

  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regConfirm, setRegConfirm] = useState('');

  const [forgotEmail, setForgotEmail] = useState('');

  // Global Alert / Toasts
  const [alertInfo, setAlertInfo] = useState('');
  const [alertError, setAlertError] = useState('');
  const [isSubmitPending, setIsSubmitPending] = useState(false);

  // Load Session on startup
  useEffect(() => {
    if (token) {
      loadUserSession(token);
    } else {
      setIsLoadingSession(false);
    }
  }, [token]);

  // Handle Dark mode theme toggles
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  // Load statistics on dashboard navigate
  useEffect(() => {
    if (user && activeTab === 'dashboard') {
      fetchDashboardStatistics();
    }
  }, [user, activeTab]);

  const loadUserSession = async (authToken: string) => {
    try {
      const res = await fetch('/api/auth/session', {
        headers: {
          'Authorization': `Bearer ${authToken}`
        }
      });
      const data = await res.json();
      if (data.error) {
        // invalid or expired token
        handleLogoutAction();
      } else if (data.user) {
        setUser(data.user);
      }
    } catch (err) {
      console.error('Session loading failed:', err);
    } finally {
      setIsLoadingSession(false);
    }
  };

  const fetchDashboardStatistics = async () => {
    if (!token) return;
    try {
      const res = await fetch('/api/stats', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      const data = await res.json();
      if (!data.error) {
        setDashboardStats(data);
      }
    } catch (err) {
      console.error('Failed to sync dashboard analytics:', err);
    }
  };

  // Auth Operations
  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAlertInfo('');
    setAlertError('');
    setIsSubmitPending(true);

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: loginEmail, password: loginPassword, rememberMe })
      });
      const data = await res.json();

      if (data.error) {
        throw new Error(data.error);
      }

      setToken(data.token);
      localStorage.setItem('interview_token', data.token);
      setUser(data.user);
      setAlertInfo('Welcome back! Loading placement prep assets...');
      
      // Cleanup inputs
      setLoginEmail('');
      setLoginPassword('');
    } catch (err: any) {
      setAlertError(err.message || 'Login failed, please check credentials.');
    } finally {
      setIsSubmitPending(false);
    }
  };

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAlertInfo('');
    setAlertError('');
    setIsSubmitPending(true);

    if (regPassword !== regConfirm) {
      setAlertError('Passwords do not match with each other');
      setIsSubmitPending(false);
      return;
    }

    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: regName, email: regEmail, password: regPassword, confirmPassword: regConfirm })
      });
      const data = await res.json();

      if (data.error) {
        throw new Error(data.error);
      }

      setToken(data.token);
      localStorage.setItem('interview_token', data.token);
      setUser(data.user);
      setAlertInfo('Registration successful! Launching placement profile...');
      
      // Cleanup inputs
      setRegName('');
      setRegEmail('');
      setRegPassword('');
      setRegConfirm('');
    } catch (err: any) {
      setAlertError(err.message || 'Registration failed. Check duplicate emails.');
    } finally {
      setIsSubmitPending(false);
    }
  };

  const handleForgotSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setAlertInfo('');
    setAlertError('');
    if (!forgotEmail) {
      setAlertError('Please list your registered email address');
      return;
    }
    setAlertInfo(`Demo Alert: A simulated security token has been generated. Normally we send a password reset mail directly to: ${forgotEmail}. Support account credentials: student@placement.com / studentpassword`);
  };

  const handleLogoutAction = () => {
    localStorage.removeItem('interview_token');
    setToken(null);
    setUser(null);
    setActiveTab('dashboard');
    setActiveInterview(null);
    setActiveReport(null);
    setAlertInfo('Logged out of placement prep safely.');
  };

  // Profile operations mapping
  const handleProfileUpdate = async (newName: string, newImage: string) => {
    if (!token) return;
    const res = await fetch('/api/profile/update', {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ name: newName, profile_image: newImage })
    });
    const data = await res.json();
    if (data.error) throw new Error(data.error);

    setUser(data.user);
  };

  const handlePasswordUpdate = async (current: string, next: string, confirm: string) => {
    if (!token) return;
    const res = await fetch('/api/profile/password', {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ currentPassword: current, newPassword: next, confirmNewPassword: confirm })
    });
    const data = await res.json();
    if (data.error) throw new Error(data.error);
  };

  // Interview Arena logic hooks
  const startInterviewSession = async (config: {
    role: string;
    interview_type: string;
    difficulty: string;
    questionCount: number;
    timer: number;
    mode: 'voice' | 'text';
  }) => {
    if (!token) return;
    setAlertError('');
    setIsSubmitPending(true);

    try {
      const res = await fetch('/api/interviews/start', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(config)
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error);

      setActiveInterview(data.interview);
      setActiveTab('live');
    } catch (err: any) {
      setAlertError(err.message || 'Failed to initialize session');
    } finally {
      setIsSubmitPending(false);
    }
  };

  const evaluateQuestionAnswer = async (questionId: string, userAnswer: string, timeSeconds: number): Promise<AnswerEvaluation> => {
    if (!token || !activeInterview) throw new Error('Missing interview context');
    const res = await fetch('/api/interviews/evaluate', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({
        interviewId: activeInterview.id,
        questionId,
        userAnswer,
        timeTaken: timeSeconds
      })
    });
    const data = await res.json();
    if (data.error) throw new Error(data.error);
    return data.evaluation;
  };

  const completeActiveInterview = async (interviewId: string) => {
    if (!token) return;
    setAlertError('');
    try {
      const res = await fetch('/api/interviews/complete', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ interviewId })
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error);

      // Successfully compiled results! Load detailed ReportViewer card
      viewSpecificReport(data.result.id);
    } catch (err: any) {
      setAlertError(err.message || 'Failed compile scores');
    }
  };

  const viewSpecificReport = async (reportId: string) => {
    if (!token) return;
    try {
      const res = await fetch(`/api/results/${reportId}`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error);

      setActiveReport(data);
      setActiveTab('report');
    } catch (err: any) {
      setAlertError(err.message || 'Failed to fetch report audit');
    }
  };


  if (isLoadingSession) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col items-center justify-center space-y-3 font-sans">
        <svg className="animate-spin h-8 w-8 text-indigo-600" fill="none" viewBox="0 0 24 24">
          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
        </svg>
        <span className="text-sm font-semibold text-slate-550 dark:text-slate-400">Booting Placement Prep Portal...</span>
      </div>
    );
  }

  // ==========================================
  // UNAUTHENTICATED WALL LAYOUT
  // ==========================================
  if (!user) {
    return (
      <div className={`min-h-screen ${darkMode ? 'dark bg-slate-950 text-white' : 'bg-slate-50 text-slate-900'} flex flex-col font-sans transition-colors duration-200`}>
        
        {/* Authentication portal top right utility header */}
        <header className="max-w-7xl w-full mx-auto p-4 flex justify-between items-center bg-transparent relative z-10">
          <div className="flex items-center gap-2">
            <div className="bg-indigo-605 p-2 rounded-xl text-white">
              <GraduationCap className="w-5 h-5" />
            </div>
            <span className="font-extrabold text-sm md:text-base tracking-tight dark:text-white">PrepHub</span>
          </div>
          
          <button
            onClick={() => setDarkMode(!darkMode)}
            id="btn-theme-unauth"
            className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-900 transition-colors cursor-pointer"
          >
            {darkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-slate-700" />}
          </button>
        </header>

        {/* Form panel body */}
        <main className="grow flex items-center justify-center px-4 py-8 relative">
          <div className="absolute right-1/4 top-1/4 w-96 h-96 bg-indigo-505/10 rounded-full blur-3xl pointer-events-none"></div>
          <div className="absolute left-1/4 bottom-1/4 w-96 h-96 bg-purple-505/10 rounded-full blur-3xl pointer-events-none"></div>

          <div className="max-w-md w-full bg-white dark:bg-slate-900 border border-slate-205 dark:border-slate-800 rounded-3xl shadow-xl overflow-hidden relative z-10">
            <div className="p-6 md:p-8 space-y-6">
              
              {/* Header tags */}
              <div className="text-center space-y-1.5">
                <span className="bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 text-[10px] px-2.5 py-1 rounded-full font-bold border border-indigo-100 dark:border-indigo-900/30">
                  AI-POWERED PREPARATION ENGINE
                </span>
                <h2 className="text-2xl font-black text-slate-900 dark:text-white">AI Placement Practice Portal</h2>
                <p className="text-xs text-slate-500 dark:text-slate-400">Simulate interviews, evaluate results, and secure target offers.</p>
              </div>

              {alertInfo && (
                <div className="bg-emerald-50 dark:bg-emerald-950/20 text-emerald-700 dark:text-emerald-400 border border-emerald-100 dark:border-emerald-900/40 p-3.5 rounded-xl text-xs font-semibold leading-relaxed">
                  {alertInfo}
                </div>
              )}

              {alertError && (
                <div className="bg-rose-50 dark:bg-rose-955/20 text-rose-700 dark:text-rose-450 border border-rose-100 dark:border-rose-900/40 p-3.5 rounded-xl text-xs font-semibold leading-relaxed animate-shake">
                  {alertError}
                </div>
              )}

              {/* 1. LOGIN INTERFACE */}
              {authMode === 'login' && (
                <form onSubmit={handleLoginSubmit} className="space-y-4" id="form-login">
                  <div className="space-y-1.5">
                    <label htmlFor="input-login-email" className="text-xs font-bold text-slate-650 dark:text-slate-350 block">Registered Email Address</label>
                    <input
                      id="input-login-email"
                      type="email"
                      required
                      placeholder="e.g. student@placement.com"
                      value={loginEmail}
                      onChange={(e) => setLoginEmail(e.target.value)}
                      className="w-full bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-3 text-xs focus:border-indigo-505 outline-none"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <div className="flex justify-between items-center">
                      <label htmlFor="input-login-pass" className="text-xs font-bold text-slate-650 dark:text-slate-350 block">Security Password</label>
                      <button
                        type="button"
                        onClick={() => { setAuthMode('forgot'); setAlertError(''); setAlertInfo(''); }}
                        className="text-[10px] font-bold text-indigo-600 dark:text-indigo-400 hover:underline cursor-pointer"
                      >
                        Forgot password?
                      </button>
                    </div>
                    <input
                      id="input-login-pass"
                      type="password"
                      required
                      placeholder="e.g. studentpassword"
                      value={loginPassword}
                      onChange={(e) => setLoginPassword(e.target.value)}
                      className="w-full bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-3 text-xs focus:border-indigo-505 outline-none"
                    />
                  </div>

                  {/* Remember me toggle */}
                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      id="cb-remember-me"
                      checked={rememberMe}
                      onChange={(e) => setRememberMe(e.target.checked)}
                      className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                    />
                    <label htmlFor="cb-remember-me" className="text-[11px] text-slate-500 dark:text-slate-400 cursor-pointer font-medium select-none">Remember my session criteria</label>
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmitPending}
                    id="btn-login-submit"
                    className="w-full bg-indigo-650 hover:bg-indigo-700 text-white font-extrabold py-3.5 rounded-xl text-xs shadow-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
                  >
                    {isSubmitPending ? 'Authenticating credentials...' : 'Enter Prep Portal'}
                  </button>

                  <div className="pt-2 text-center text-[10px] text-slate-400 leading-relaxed">
                    Demo credentials - Student: <code className="bg-slate-100 dark:bg-slate-950 px-1 py-0.5 rounded text-[10px]">student@placement.com</code> / <code className="bg-slate-100 dark:bg-slate-950 px-1 py-0.5 rounded text-[10px]">studentpassword</code><br />
                    Admin access: <code className="bg-slate-100 dark:bg-slate-950 px-1 py-0.5 rounded text-[10px]">admin@placement.com</code> / <code className="bg-slate-100 dark:bg-slate-950 px-1 py-0.5 rounded text-[10px]">adminpassword</code>
                  </div>
                </form>
              )}

              {/* 2. REGISTRATION INTERFACE */}
              {authMode === 'register' && (
                <form onSubmit={handleRegisterSubmit} className="space-y-4" id="form-register">
                  <div className="space-y-1.5">
                    <label htmlFor="input-reg-name" className="text-xs font-bold text-slate-650 dark:text-slate-350 block">Candidate Full Name</label>
                    <input
                      id="input-reg-name"
                      type="text"
                      required
                      placeholder="e.g. John Doe"
                      value={regName}
                      onChange={(e) => setRegName(e.target.value)}
                      className="w-full bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-3 text-xs focus:border-indigo-505 outline-none"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label htmlFor="input-reg-email" className="text-xs font-bold text-slate-650 dark:text-slate-350 block">Preferred Email address</label>
                    <input
                      id="input-reg-email"
                      type="email"
                      required
                      placeholder="e.g. contact@domain.com"
                      value={regEmail}
                      onChange={(e) => setRegEmail(e.target.value)}
                      className="w-full bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-3 text-xs focus:border-indigo-505 outline-none"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1.5">
                      <label htmlFor="input-reg-pass" className="text-xs font-bold text-slate-650 dark:text-slate-350 block">Password</label>
                      <input
                        id="input-reg-pass"
                        type="password"
                        required
                        placeholder="••••••••"
                        value={regPassword}
                        onChange={(e) => setRegPassword(e.target.value)}
                        className="w-full bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-805 rounded-xl px-4 py-3 text-xs focus:border-indigo-505 outline-none"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <label htmlFor="input-reg-confirm" className="text-xs font-bold text-slate-650 dark:text-slate-350 block">Confirm Password</label>
                      <input
                        id="input-reg-confirm"
                        type="password"
                        required
                        placeholder="••••••••"
                        value={regConfirm}
                        onChange={(e) => setRegConfirm(e.target.value)}
                        className="w-full bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-805 rounded-xl px-4 py-3 text-xs focus:border-indigo-505 outline-none"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmitPending}
                    id="btn-reg-submit"
                    className="w-full bg-indigo-650 hover:bg-indigo-700 text-white font-extrabold py-3.5 rounded-xl text-xs shadow-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
                  >
                    {isSubmitPending ? 'Compiling account database...' : 'Register Candidate Credentials'}
                  </button>
                </form>
              )}

              {/* 3. FORGOT PASSWORD INTERFACE */}
              {authMode === 'forgot' && (
                <form onSubmit={handleForgotSubmit} className="space-y-4" id="form-forgot">
                  <div className="space-y-1.5">
                    <label htmlFor="input-forgot-email" className="text-xs font-bold text-slate-650 dark:text-slate-350 block">Account Email address</label>
                    <input
                      id="input-forgot-email"
                      type="email"
                      required
                      placeholder="e.g. student@placement.com"
                      value={forgotEmail}
                      onChange={(e) => setForgotEmail(e.target.value)}
                      className="w-full bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-3 text-xs focus:border-indigo-505 outline-none"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-slate-900 hover:bg-slate-850 dark:bg-indigo-650 dark:hover:bg-indigo-700 text-white font-extrabold py-3.5 rounded-xl text-xs flex items-center justify-center gap-1 hover:slate-850 cursor-pointer"
                  >
                    Trigger Password Reset Mails
                  </button>

                  <button
                    type="button"
                    onClick={() => { setAuthMode('login'); setAlertError(''); setAlertInfo(''); }}
                    className="w-full text-xs font-bold text-slate-400 hover:text-slate-600 transition-colors cursor-pointer text-center"
                  >
                    Never Mind - Retrace Steps to Login
                  </button>
                </form>
              )}

              {/* Routing footer toggler */}
              <div className="border-t border-slate-100 dark:border-slate-800 pt-4 text-center">
                {authMode === 'login' ? (
                  <p className="text-[11px] text-slate-500">
                    Are you a new candidate?{' '}
                    <button
                      onClick={() => { setAuthMode('register'); setAlertError(''); setAlertInfo(''); }}
                      className="text-indigo-605 font-bold hover:underline cursor-pointer"
                    >
                      Create credential file
                    </button>
                  </p>
                ) : authMode === 'register' ? (
                  <p className="text-[11px] text-slate-500">
                    Already registered?{' '}
                    <button
                      onClick={() => { setAuthMode('login'); setAlertError(''); setAlertInfo(''); }}
                      className="text-indigo-605 font-bold hover:underline cursor-pointer"
                    >
                      Authenticate credentials
                    </button>
                  </p>
                ) : null}
              </div>

            </div>
          </div>
        </main>
      </div>
    );
  }

  // ==========================================
  // AUTHENTICATED WORKSPACE MODULE
  // ==========================================
  return (
    <div className={`min-h-screen ${darkMode ? 'dark bg-slate-950 text-white' : 'bg-slate-50 text-slate-900'} flex font-sans transition-colors duration-150`}>
      
      {/* Dynamic Responsive Sidebar drawer */}
      <aside className={`fixed inset-y-0 left-0 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-850 w-64 z-40 transform transition-transform duration-200 lg:translate-x-0 ${
        sidebarOpen ? 'translate-x-0' : '-translate-x-full'
      }`}>
        <div className="p-6 h-full flex flex-col justify-between">
          <div className="space-y-6">
            
            {/* Sidebar Branding logo */}
            <div className="flex items-center gap-2 mb-8">
              <div className="bg-indigo-600 p-2 rounded-xl text-white">
                <GraduationCap className="w-5 h-5" />
              </div>
              <div className="space-y-0.5">
                <span className="font-extrabold text-sm md:text-base tracking-tight dark:text-white">MockArena</span>
                <span className="block text-[9px] text-slate-400 font-extrabold uppercase tracking-widest">Placement Prep</span>
              </div>
            </div>

            {/* Selection Options lists */}
            <nav className="space-y-1 text-xs font-bold" id="sidebar-nav">
              <button
                onClick={() => { setActiveTab('dashboard'); setSidebarOpen(false); }}
                className={`w-full flex items-center justify-between px-4 py-3 rounded-xl transition-all cursor-pointer ${
                  activeTab === 'dashboard'
                    ? 'bg-indigo-50 text-indigo-605 dark:bg-indigo-950/40 dark:text-indigo-400'
                    : 'text-slate-650 hover:bg-slate-50 dark:text-slate-350 dark:hover:bg-slate-950/20'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-indigo-500"></span>
                  Student Dashboard
                </div>
                <ChevronRight className="w-3.5 h-3.5 opacity-40" />
              </button>

              <button
                onClick={() => { setActiveTab('practice'); setSidebarOpen(false); }}
                className={`w-full flex items-center justify-between px-4 py-3 rounded-xl transition-all cursor-pointer ${
                  activeTab === 'practice' || activeTab === 'live'
                    ? 'bg-indigo-50 text-indigo-655 dark:bg-indigo-950/40 dark:text-indigo-400'
                    : 'text-slate-650 hover:bg-slate-50 dark:text-slate-350 dark:hover:bg-slate-950/20'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                  Start Practice
                </div>
                <ChevronRight className="w-3.5 h-3.5 opacity-40" />
              </button>

              <button
                onClick={() => { setActiveTab('profile'); setSidebarOpen(false); }}
                className={`w-full flex items-center justify-between px-4 py-3 rounded-xl transition-all cursor-pointer ${
                  activeTab === 'profile'
                    ? 'bg-indigo-50 text-indigo-655 dark:bg-indigo-950/40 dark:text-indigo-400'
                    : 'text-slate-650 hover:bg-slate-50 dark:text-slate-350 dark:hover:bg-slate-950/20'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-purple-500"></span>
                  Assessments profile
                </div>
                <ChevronRight className="w-3.5 h-3.5 opacity-40" />
              </button>

              {user.isAdmin && (
                <button
                  onClick={() => { setActiveTab('admin'); setSidebarOpen(false); }}
                  className={`w-full flex items-center justify-between px-4 py-3 rounded-xl border border-dashed border-rose-200 dark:border-rose-900/30 transition-all cursor-pointer ${
                    activeTab === 'admin'
                      ? 'bg-rose-50 text-rose-700 dark:bg-rose-950/40 dark:text-rose-400'
                      : 'text-rose-650 hover:bg-rose-50/20 dark:text-rose-350'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Shield className="w-4 h-4 text-rose-500" />
                    Admin dashboard
                  </div>
                  <ChevronRight className="w-3.5 h-3.5 opacity-40" />
                </button>
              )}
            </nav>
          </div>

          {/* Connected User Status Profile block */}
          <div className="border-t border-slate-100 dark:border-slate-800 pt-4 space-y-3">
            <div className="flex items-center gap-3">
              <img
                src={user.profile_image || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150'}
                alt="Profile avatar"
                className="w-10 h-10 rounded-full object-cover border border-slate-200 dark:border-slate-850"
              />
              <div className="space-y-0.5 overflow-hidden">
                <span className="font-bold text-slate-905 dark:text-white text-xs block truncate">{user.name}</span>
                <span className="text-[10px] text-slate-400 block truncate">{user.email}</span>
              </div>
            </div>

            <button
              onClick={handleLogoutAction}
              id="btn-logout"
              className="w-full bg-slate-50 hover:bg-slate-100 dark:bg-slate-950 hover:dark:bg-slate-850 text-slate-700 dark:text-slate-300 font-extrabold py-2.5 rounded-xl text-xs flex items-center justify-center gap-1 border border-slate-150 dark:border-slate-850 cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
              Sign Off Credentials
            </button>
          </div>

        </div>
      </aside>

      {/* Main workspace arena */}
      <div className="flex-1 lg:pl-64 flex flex-col min-h-screen">
        
        {/* Top bar controls */}
        <header className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-850 p-4 sticky top-0 z-30 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="lg:hidden p-2 rounded-lg border border-slate-200 dark:border-slate-800"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="hidden lg:flex items-center gap-1 text-xs font-semibold text-slate-500 dark:text-slate-400">
              <span>Placement Prepare Hub</span>
              <span className="text-slate-350">/</span>
              <span className="text-indigo-650 opacity-90 capitalize font-bold">{activeTab} workspace</span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setDarkMode(!darkMode)}
              className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-950 transition-colors cursor-pointer"
              title="Toggle theme view"
            >
              {darkMode ? <Sun className="w-4.5 h-4.5 text-amber-400" /> : <Moon className="w-4.5 h-4.5 text-slate-700" />}
            </button>
            <div className="h-8 w-[1px] bg-slate-200 dark:bg-slate-800"></div>
            <div className="bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400 text-[10px] font-black px-2.5 py-1 rounded-full border border-emerald-100 dark:border-emerald-900/35">
              Live Connection
            </div>
          </div>
        </header>

        {/* Content viewport area */}
        <main className="p-6 md:p-8 grow">
          <div className="max-w-7xl mx-auto">
            
            {activeTab === 'dashboard' && dashboardStats && (
              <Dashboard
                stats={dashboardStats}
                onViewReport={(resultId) => viewSpecificReport(resultId)}
                onNavigateToPractice={() => setActiveTab('practice')}
              />
            )}

            {activeTab === 'practice' && (
              <PracticeSettings
                onStartInterview={(config) => startInterviewSession(config)}
                isStarting={isSubmitPending}
              />
            )}

            {activeTab === 'live' && activeInterview && (
              <LiveArena
                interviewData={activeInterview}
                onEvaluateQuestion={(qId, ans, tm) => evaluateQuestionAnswer(qId, ans, tm)}
                onCompleteInterview={(intId) => completeActiveInterview(intId)}
              />
            )}

            {activeTab === 'report' && activeReport && (
              <ReportViewer
                reportData={activeReport}
                onBackToDashboard={() => { setActiveTab('dashboard'); fetchDashboardStatistics(); }}
                onRestartPractice={() => { setActiveTab('practice'); }}
              />
            )}

            {activeTab === 'profile' && user && (
              <Profile
                user={user}
                onUpdateValue={(n, img) => handleProfileUpdate(n, img)}
                onChangePasswordValue={(curr, nxt, conf) => handlePasswordUpdate(curr, nxt, conf)}
              />
            )}

            {activeTab === 'admin' && (
              <AdminPanel
                token={token || ''}
                onRefreshMetrics={() => fetchDashboardStatistics()}
              />
            )}

          </div>
        </main>

      </div>
    </div>
  );
}
