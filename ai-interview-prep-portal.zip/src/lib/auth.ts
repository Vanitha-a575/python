import crypto from 'crypto';

const JWT_SECRET = process.env.JWT_SECRET || 'ai_interview_practice_portal_super_private_token_secret_key';

// Secure PBKDF2 Password Hashing
export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.pbkdf2Sync(password, salt, 1000, 64, 'sha512').toString('hex');
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, storedHash: string): boolean {
  try {
    const [salt, hash] = storedHash.split(':');
    const computedHash = crypto.pbkdf2Sync(password, salt, 1000, 64, 'sha512').toString('hex');
    return computedHash === hash;
  } catch (err) {
    return false;
  }
}

// Pure Node.js Standard Cryptographic JWT Implementation
interface JWTPayload {
  id: string;
  email: string;
  isAdmin?: boolean;
  exp: number;
}

function base64url(source: Buffer | string): string {
  let encoded = typeof source === 'string' 
    ? Buffer.from(source).toString('base64') 
    : source.toString('base64');
  return encoded
    .replace(/=/g, '')
    .replace(/\+/g, '-')
    .replace(/\//g, '_');
}

function base64urlDecode(source: string): string {
  let decoded = source
    .replace(/-/g, '+')
    .replace(/_/g, '/');
  while (decoded.length % 4) {
    decoded += '=';
  }
  return Buffer.from(decoded, 'base64').toString('utf8');
}

export function signJWT(payload: Omit<JWTPayload, 'exp'>, expiresInHours: number = 24): string {
  const header = {
    alg: 'HS256',
    typ: 'JWT'
  };

  const exp = Math.floor(Date.now() / 1000) + (expiresInHours * 60 * 60);
  const fullPayload = { ...payload, exp };

  const encodedHeader = base64url(JSON.stringify(header));
  const encodedPayload = base64url(JSON.stringify(fullPayload));

  const signatureInput = `${encodedHeader}.${encodedPayload}`;
  const hmac = crypto.createHmac('sha256', JWT_SECRET);
  hmac.update(signatureInput);
  const signature = base64url(hmac.digest());

  return `${encodedHeader}.${encodedPayload}.${signature}`;
}

export function verifyJWT(token: string): JWTPayload | null {
  try {
    const parts = token.split('.');
    if (parts.length !== 3) return null;

    const [headerB64, payloadB64, signatureB64] = parts;

    // Verify signature
    const signatureInput = `${headerB64}.${payloadB64}`;
    const hmac = crypto.createHmac('sha256', JWT_SECRET);
    hmac.update(signatureInput);
    const computedSignature = base64url(hmac.digest());

    if (computedSignature !== signatureB64) {
      return null;
    }

    const payload: JWTPayload = JSON.parse(base64urlDecode(payloadB64));
    
    // Check expiration
    if (payload.exp < Math.floor(Date.now() / 1000)) {
      return null;
    }

    return payload;
  } catch (err) {
    return null;
  }
}
