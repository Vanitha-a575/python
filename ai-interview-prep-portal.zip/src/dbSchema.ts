import fs from 'fs';
import path from 'path';
import { User, Question, Interview, Result } from './types';
import { hashPassword } from './lib/auth';
import { generateQuestionBank } from './data/questions';

const DB_FILE_PATH = path.join(process.cwd(), 'database_storage.json');

interface DatabaseSchema {
  users: User[];
  questions: Question[];
  interviews: Interview[];
  results: Result[];
}

// Check and initialize file database
export function getDatabase(): DatabaseSchema {
  try {
    if (fs.existsSync(DB_FILE_PATH)) {
      const content = fs.readFileSync(DB_FILE_PATH, 'utf8');
      const parsed = JSON.parse(content);
      
      // Ensure basic arrays exist
      if (!parsed.users) parsed.users = [];
      if (!parsed.questions || parsed.questions.length === 0) {
        parsed.questions = generateQuestionBank();
      }
      if (!parsed.interviews) parsed.interviews = [];
      if (!parsed.results) parsed.results = [];
      
      return parsed;
    }
  } catch (err) {
    console.error('Failed reading file database, returning initialized model:', err);
  }

  // Preseed default database
  const questions = generateQuestionBank();
  
  const seedAdmin: User = {
    id: 'u-admin',
    name: 'System Admin',
    email: 'admin@placement.com',
    password: hashPassword('adminpassword'),
    isAdmin: true,
    profile_image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
    created_at: new Date().toISOString()
  };

  const seedStudent: User = {
    id: 'u-student',
    name: 'Vance Placement',
    email: 'student@placement.com',
    password: hashPassword('studentpassword'),
    isAdmin: false,
    profile_image: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150',
    created_at: new Date().toISOString()
  };

  const db: DatabaseSchema = {
    users: [seedAdmin, seedStudent],
    questions,
    interviews: [],
    results: []
  };

  // Preseed a few completed mock interviews for the student to make the analytics look incredible right away!
  const mockInterviews: Interview[] = [
    {
      id: 'mock-1',
      user_id: 'u-student',
      role: 'Web Developer',
      interview_type: 'Technical',
      difficulty: 'Beginner',
      date: new Date(Date.now() - 7 * 24 * 3600 * 1000).toISOString(), // 7 days ago
      overall_score: 72,
      technical_score: 75,
      communication_score: 68,
      confidence_score: 70,
      time_settings: 60,
      mode: 'text',
      status: 'completed',
      questions: [
        {
          id: 'q-1',
          role: 'Web Developer',
          category: 'Technical',
          difficulty: 'Beginner',
          question: 'Explain the difference between let, const, and var in JavaScript.',
          expected_keywords: ['block scope', 'hoisting', 'reassignment'],
          sample_answer: 'let/const block, var function level',
          userAnswer: 'var is scoped to functions and has hoisting. let and const are ES6 standards that provide block scoping. const prevents dynamic reassignments.',
          timeTaken: 42,
          evaluation: {
            score: 75,
            technical_score: 75,
            communication_score: 70,
            confidence_score: 80,
            relevance: 'Highly relevant definition.',
            technicalAccuracy: 'Accurate distinction between scopes and reassignments.',
            completeness: 'Missed detailed Temporal Dead Zone explanation.',
            communicationQuality: 'Clear, concise layout.',
            grammar: 'Correct grammar.',
            keywordCoverage: { covered: ['block scope', 'hoisting', 'reassignment'], missed: [], percentage: 100 },
            strengths: ['Correct core definitions'],
            weaknesses: ['Missed Temporal Dead zone'],
            suggestions: ['Explain runtime scope contexts']
          }
        }
      ]
    },
    {
      id: 'mock-2',
      user_id: 'u-student',
      role: 'Full Stack Developer',
      interview_type: 'Mock Placement',
      difficulty: 'Intermediate',
      date: new Date(Date.now() - 3 * 24 * 3600 * 1000).toISOString(), // 3 days ago
      overall_score: 85,
      technical_score: 88,
      communication_score: 82,
      confidence_score: 85,
      time_settings: 60,
      mode: 'voice',
      status: 'completed',
      questions: [
        {
          id: 'q-7',
          role: 'Full Stack Developer',
          category: 'Technical',
          difficulty: 'Intermediate',
          question: 'What are JWTs (JSON Web Tokens), and how do you implement secure user sessions with them?',
          expected_keywords: ['header', 'payload', 'signature', 'access token'],
          sample_answer: 'Claims containing base64 fragments signed via key pairs.',
          userAnswer: 'JWTs are compact, self-contained tokens containing header, payload, and signature sections. They are stored as access tokens to authenticate user interactions securely.',
          timeTaken: 38,
          evaluation: {
            score: 88,
            technical_score: 88,
            communication_score: 85,
            confidence_score: 85,
            relevance: 'Excellent summary.',
            technicalAccuracy: 'Clearly explained token layout.',
            completeness: 'Complete with proper token structure.',
            communicationQuality: 'Fluent, structured, very professional speaking pace.',
            grammar: 'Excellent grammar.',
            keywordCoverage: { covered: ['header', 'payload', 'signature', 'access token'], missed: [], percentage: 100 },
            strengths: ['Thorough technical listing'],
            weaknesses: ['Did not discuss cookies risk'],
            suggestions: ['Discuss httpOnly secure cookie strategy']
          }
        }
      ]
    }
  ];

  const mockResults: Result[] = mockInterviews.map(inter => ({
    id: `r-${inter.id}`,
    user_id: inter.user_id,
    interview_id: inter.id,
    role: inter.role,
    interview_type: inter.interview_type,
    date: inter.date,
    technical_score: inter.technical_score,
    communication_score: inter.communication_score,
    confidence_score: inter.confidence_score,
    overall_score: inter.overall_score,
    strengths: ['Great command over core terminology', 'Proper formulation of practical components'],
    weaknesses: ['Slightly quick speech delivery', 'Could elaborate on environmental variable isolation techniques'],
    improvement_suggestions: ['Practice relaxing speech delivery under timers', 'Incorporate more structural framework diagrams in design reasoning'],
    recommended_resources: [
      {
        topic: 'JavaScript Closures and Scope',
        description: 'Deep dive into standard variables scope hierarchies and Hoisting mechanics.',
        resource: 'MDN Web Docs - Scope and Closures'
      },
      {
        topic: 'Web Token Authentication Best Practices',
        description: 'Secure session handling, CSRF counters, and XSS containment techniques.',
        resource: 'OWASP Session Management Guide'
      }
    ]
  }));

  db.interviews = mockInterviews;
  db.results = mockResults;

  saveDatabase(db);
  return db;
}

export function saveDatabase(db: DatabaseSchema): void {
  try {
    fs.writeFileSync(DB_FILE_PATH, JSON.stringify(db, null, 2), 'utf8');
  } catch (err) {
    console.error('Failed writing file database:', err);
  }
}
