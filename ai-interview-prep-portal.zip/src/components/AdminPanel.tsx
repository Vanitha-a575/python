import React, { useState, useEffect } from 'react';
import { AdminStats, Question, User } from '../types';
import { Database, Plus, Trash2, Edit, Search, Users, HelpCircle, Layers, ArrowRight, Save, X, BookOpen, Clock, AlertTriangle } from 'lucide-react';

interface AdminPanelProps {
  token: string;
  onRefreshMetrics: () => void;
}

export default function AdminPanel({ token, onRefreshMetrics }: AdminPanelProps) {
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [activeSubTab, setActiveSubTab] = useState<'metrics' | 'questions' | 'users'>('metrics');
  
  // Search state
  const [qSearch, setQSearch] = useState('');
  const [uSearch, setUSearch] = useState('');

  // Editing overlay trigger state
  const [showForm, setShowForm] = useState(false);
  const [formMode, setFormMode] = useState<'add' | 'edit'>('add');
  const [editingId, setEditingId] = useState<string | null>(null);

  // Form Fields
  const [roleField, setRoleField] = useState('Web Developer');
  const [categoryField, setCategoryField] = useState('Technical');
  const [difficultyField, setDifficultyField] = useState('Intermediate');
  const [questionField, setQuestionField] = useState('');
  const [keywordsField, setKeywordsField] = useState('');
  const [sampleAnswerField, setSampleAnswerField] = useState('');

  // Status logs
  const [infoLog, setInfoLog] = useState('');
  const [errLog, setErrLog] = useState('');
  const [isSubmitActive, setIsSubmitActive] = useState(false);

  useEffect(() => {
    fetchAdminData();
  }, [activeSubTab]);

  const fetchAdminData = async () => {
    try {
      if (activeSubTab === 'metrics') {
        const res = await fetch('/api/admin/stats', {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        const data = await res.json();
        if (data.error) throw new Error(data.error);
        setStats(data);
      } else if (activeSubTab === 'questions') {
        const res = await fetch('/api/admin/questions', {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        const data = await res.json();
        if (data.error) throw new Error(data.error);
        setQuestions(data.questions || []);
      } else if (activeSubTab === 'users') {
        const res = await fetch('/api/admin/users', {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        const data = await res.json();
        if (data.error) throw new Error(data.error);
        setUsers(data.users || []);
      }
    } catch (err: any) {
      setErrLog(err.message || 'Failed to sync admin details');
    }
  };

  const handleCreateOrEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitActive(true);
    setInfoLog('');
    setErrLog('');

    if (!questionField || !keywordsField || !sampleAnswerField) {
      setErrLog('Validation error: Please complete all core question fields');
      setIsSubmitActive(false);
      return;
    }

    const payload = {
      role: categoryField === 'Technical' ? roleField : 'Any',
      category: categoryField,
      difficulty: difficultyField,
      question: questionField.trim(),
      expected_keywords: keywordsField.split(',').map(tag => tag.trim()).filter(Boolean),
      sample_answer: sampleAnswerField.trim()
    };

    try {
      if (formMode === 'add') {
        const res = await fetch('/api/admin/questions', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify(payload)
        });
        const data = await res.json();
        if (data.error) throw new Error(data.error);
        setInfoLog('Custom question injected into target bank successfully!');
      } else {
        const res = await fetch(`/api/admin/questions/${editingId}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify(payload)
        });
        const data = await res.json();
        if (data.error) throw new Error(data.error);
        setInfoLog('Target question properties modified successfully!');
      }

      // Close modal & sync list
      setShowForm(false);
      resetForm();
      fetchAdminData();
    } catch (err: any) {
      setErrLog(err.message || 'Operation failed');
    } finally {
      setIsSubmitActive(false);
    }
  };

  const resetForm = () => {
    setRoleField('Web Developer');
    setCategoryField('Technical');
    setDifficultyField('Intermediate');
    setQuestionField('');
    setKeywordsField('');
    setSampleAnswerField('');
    setEditingId(null);
  };

  const handleEditButtonPress = (q: Question) => {
    setFormMode('edit');
    setEditingId(q.id);
    setRoleField(q.role || 'Web Developer');
    setCategoryField(q.category);
    setDifficultyField(q.difficulty);
    setQuestionField(q.question);
    setKeywordsField(q.expected_keywords.join(', '));
    setSampleAnswerField(q.sample_answer);
    setShowForm(true);
  };

  const handleDeleteButtonPress = async (id: string) => {
    if (!window.confirm('Delete Action: Are you absolutely sure you want to delete this question? This action is non-reversible.')) {
      return;
    }

    try {
      const res = await fetch(`/api/admin/questions/${id}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error);

      setInfoLog('Item removed from central question database.');
      fetchAdminData();
    } catch (err: any) {
      setErrLog(err.message || 'Deletion failed');
    }
  };

  const filteredQuestions = questions.filter(q => {
    const val = qSearch.toLowerCase();
    return q.question.toLowerCase().includes(val) || q.category.toLowerCase().includes(val) || q.role.toLowerCase().includes(val);
  });

  const filteredUsers = users.filter(u => {
    const val = uSearch.toLowerCase();
    return u.name.toLowerCase().includes(val) || u.email.toLowerCase().includes(val);
  });

  return (
    <div className="space-y-6" id="admin-panel-container">
      
      {/* Admin sub-navigation tabs */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-slate-205 dark:border-slate-800 pb-3 gap-4">
        <div className="space-y-1">
          <span className="bg-indigo-600 text-white font-black text-[9px] uppercase px-2.5 py-0.5 rounded tracking-widest block w-max">ADMIN SECURE ACCESS</span>
          <h2 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">Control Center & Database Admin</h2>
        </div>

        {/* Tab triggers */}
        <div className="flex gap-1.5 bg-slate-100 dark:bg-slate-950 p-1 rounded-xl border border-slate-200 dark:border-slate-850">
          <button
            onClick={() => { setActiveSubTab('metrics'); setInfoLog(''); setErrLog(''); }}
            className={`px-4 py-2 text-xs font-bold rounded-lg cursor-pointer transition-all ${
              activeSubTab === 'metrics' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-600 dark:text-slate-400 hover:text-slate-905'
            }`}
          >
            Site Metrics
          </button>
          <button
            onClick={() => { setActiveSubTab('questions'); setInfoLog(''); setErrLog(''); }}
            className={`px-4 py-2 text-xs font-bold rounded-lg cursor-pointer transition-all ${
              activeSubTab === 'questions' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-600 dark:text-slate-400 hover:text-slate-905'
            }`}
          >
            Questions Bank
          </button>
          <button
            onClick={() => { setActiveSubTab('users'); setInfoLog(''); setErrLog(''); }}
            className={`px-4 py-2 text-xs font-bold rounded-lg cursor-pointer transition-all ${
              activeSubTab === 'users' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-600 dark:text-slate-400 hover:text-slate-905'
            }`}
          >
            Registered Users ({users.length || 0})
          </button>
        </div>
      </div>

      {infoLog && (
        <div className="bg-emerald-50 dark:bg-emerald-950/20 text-emerald-700 dark:text-emerald-400 border border-emerald-100 dark:border-emerald-900/40 p-4 rounded-xl text-xs font-semibold">
          {infoLog}
        </div>
      )}

      {errLog && (
        <div className="bg-rose-50 dark:bg-rose-950/20 text-rose-700 dark:text-rose-400 border border-rose-100 dark:border-rose-900/40 p-4 rounded-xl text-xs font-semibold">
          {errLog}
        </div>
      )}

      {/* METRICS VIEW TAB */}
      {activeSubTab === 'metrics' && stats && (
        <div className="space-y-6" id="tab-metrics-panel">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-205 dark:border-slate-800 flex justify-between items-start">
              <div className="space-y-1">
                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Registered Candidate Accounts</span>
                <h3 className="text-3xl font-bold text-slate-900 dark:text-white">{stats.totalUsers}</h3>
              </div>
              <div className="bg-blue-50 dark:bg-blue-950/30 p-2.5 rounded-xl">
                <Users className="w-5 h-5 text-blue-600 dark:text-blue-400" />
              </div>
            </div>

            <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-205 dark:border-slate-800 flex justify-between items-start">
              <div className="space-y-1">
                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Total Questions Loaded</span>
                <h3 className="text-3xl font-bold text-slate-900 dark:text-white">{stats.totalQuestions}</h3>
              </div>
              <div className="bg-indigo-50 dark:bg-indigo-950/30 p-2.5 rounded-xl">
                <Database className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
              </div>
            </div>

            <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-205 dark:border-slate-800 flex justify-between items-start">
              <div className="space-y-1">
                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Attempts Graded</span>
                <h3 className="text-3xl font-bold text-slate-900 dark:text-white">{stats.totalInterviews}</h3>
              </div>
              <div className="bg-emerald-50 dark:bg-emerald-950/30 p-2.5 rounded-xl">
                <BookOpen className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
              </div>
            </div>

            <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-205 dark:border-slate-800 flex justify-between items-start">
              <div className="space-y-1">
                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Average Platform Score</span>
                <h3 className="text-3xl font-bold text-slate-900 dark:text-white">{stats.averageOverallScore}%</h3>
              </div>
              <div className="bg-purple-50 dark:bg-purple-950/30 p-2.5 rounded-xl">
                <Layers className="w-5 h-5 text-purple-600 dark:text-purple-400" />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Category distributions list */}
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6">
              <h4 className="font-extrabold text-sm text-slate-900 dark:text-white uppercase mb-4 tracking-wider">Classification pool</h4>
              <div className="space-y-4">
                {Object.entries(stats.categoryBreakdown).map(([cat, total]) => (
                  <div key={cat} className="space-y-1 text-xs">
                    <div className="flex justify-between">
                      <span className="font-bold text-slate-700 dark:text-slate-350">{cat} Questions</span>
                      <span className="text-slate-500 font-medium">{total} items</span>
                    </div>
                    <div className="w-full bg-slate-100 dark:bg-slate-950 h-2 rounded-full">
                      <div className="bg-indigo-600 h-2 rounded-full" style={{ width: `${Math.min(100, (total / stats.totalQuestions) * 100)}%` }}></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Site wide recent attempts list table */}
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 col-span-2">
              <h4 className="font-extrabold text-sm text-slate-900 dark:text-white uppercase mb-4 tracking-wider">Recent placement submissions</h4>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-slate-600 dark:text-slate-400">
                  <thead>
                    <tr className="border-b border-slate-100 dark:border-slate-800 font-bold">
                      <th className="pb-3 px-2">Account</th>
                      <th className="pb-3 px-2">Target</th>
                      <th className="pb-3 px-2">Submit Date</th>
                      <th className="pb-3 px-2 text-right">Result Score</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {stats.recentInterviews && stats.recentInterviews.length > 0 ? (
                      stats.recentInterviews.map((inter) => (
                        <tr key={inter.id}>
                          <td className="py-2.5 px-2 font-semibold text-slate-800 dark:text-slate-200">
                            <div>{inter.userName}</div>
                            <div className="text-[10px] text-slate-400 font-normal">{inter.userEmail}</div>
                          </td>
                          <td className="py-2.5 px-2">{inter.role}</td>
                          <td className="py-2.5 px-2">{new Date(inter.date).toLocaleDateString()}</td>
                          <td className="py-2.5 px-2 text-right font-extrabold text-indigo-600 dark:text-indigo-400">{inter.score}%</td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={4} className="py-6 text-center italic text-slate-400">No attempts logged across database.</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* QUESTIONS DATABASE MANAGER TAB (CRUD) */}
      {activeSubTab === 'questions' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-6" id="tab-questions-panel">
          
          {/* List Headers and triggers */}
          <div className="flex flex-col md:flex-row gap-4 justify-between items-start md:items-center">
            
            <div className="relative w-full md:max-w-sm">
              <input
                type="text"
                value={qSearch}
                onChange={(e) => setQSearch(e.target.value)}
                placeholder="Search queries, targets, categories..."
                className="w-full bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-850 rounded-xl pl-9 pr-4 py-2.5 text-xs outline-none focus:border-indigo-505"
              />
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
            </div>

            <button
              onClick={() => { setFormMode('add'); resetForm(); setShowForm(true); }}
              id="btn-add-question"
              className="bg-indigo-650 hover:bg-indigo-700 text-white font-extrabold px-4 py-2.5 rounded-xl text-xs flex items-center gap-1.5 cursor-pointer shadow-xs"
            >
              <Plus className="w-4 h-4 animate-pulse" />
              Add Custom Question
            </button>
          </div>

          {/* Core lists table */}
          <div className="overflow-x-auto text-xs">
            <table className="w-full text-left line-height-relaxed border-collapse">
              <thead>
                <tr className="border-b border-slate-100 dark:border-slate-800 text-slate-400 font-bold uppercase">
                  <th className="pb-3 px-2">Category</th>
                  <th className="pb-3 px-2">Role Target</th>
                  <th className="pb-3 px-2">Tier</th>
                  <th className="pb-3 px-4">Question Text</th>
                  <th className="pb-3 px-2">Keywords expected</th>
                  <th className="pb-3 pl-4 text-right">Settings</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-105 dark:divide-slate-800">
                {filteredQuestions.length > 0 ? (
                  filteredQuestions.map((q) => (
                    <tr key={q.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-950/40 transition-all">
                      <td className="py-3 px-2">
                        <span className={`px-2 py-0.5 rounded text-[10px] uppercase font-black ${
                          q.category === 'Technical' ? 'bg-indigo-50 text-indigo-600 dark:bg-indigo-950/40 dark:text-indigo-400' :
                          q.category === 'HR' ? 'bg-purple-50 text-purple-600 dark:bg-purple-950/40 dark:text-purple-400' :
                          'bg-amber-50 text-amber-600 dark:bg-amber-950/40'
                        }`}>
                          {q.category}
                        </span>
                      </td>
                      <td className="py-3 px-2 font-semibold text-slate-800 dark:text-slate-350">{q.role}</td>
                      <td className="py-3 px-2">
                        <span className={`font-semibold ${
                          q.difficulty === 'Advanced' ? 'text-rose-600' :
                          q.difficulty === 'Intermediate' ? 'text-amber-500' : 'text-slate-400'
                        }`}>
                          {q.difficulty}
                        </span>
                      </td>
                      <td className="py-3 px-4 max-w-xs text-slate-700 dark:text-slate-300 leading-relaxed truncate" title={q.question}>
                        {q.question}
                      </td>
                      <td className="py-3 px-2 max-w-[120px] truncate" title={q.expected_keywords.join(', ')}>
                        {q.expected_keywords.map(kw => (
                          <span key={kw} className="bg-slate-100 dark:bg-slate-850 px-1 py-0.5 rounded text-[9px] mr-1 inline-block mb-1 font-medium">{kw}</span>
                        ))}
                      </td>
                      <td className="py-3 pl-4 text-right">
                        <div className="flex gap-1 justify-end">
                          <button
                            onClick={() => handleEditButtonPress(q)}
                            className="bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 p-2 rounded-xl cursor-pointer"
                          >
                            <Edit className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleDeleteButtonPress(q.id)}
                            className="bg-rose-50 hover:bg-rose-100 text-rose-600 p-2 rounded-xl cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={6} className="py-12 text-center text-slate-400 italic">No matching questions resolved in pool.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* USER DATABASE VIEWER TAB */}
      {activeSubTab === 'users' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-6" id="tab-users-panel">
          
          <div className="relative w-full md:max-w-sm">
            <input
              type="text"
              value={uSearch}
              onChange={(e) => setUSearch(e.target.value)}
              placeholder="Filter by name, email coordinates..."
              className="w-full bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-850 rounded-xl pl-9 pr-4 py-2.5 text-xs outline-none focus:border-indigo-505"
            />
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          </div>

          <div className="overflow-x-auto text-xs">
            <table className="w-full text-left line-height-relaxed border-collapse">
              <thead>
                <tr className="border-b border-slate-100 dark:border-slate-800 text-slate-400 font-bold uppercase">
                  <th className="pb-3 px-2">Account Name</th>
                  <th className="pb-3 px-2">Email Address</th>
                  <th className="pb-3 px-2">Portal Role</th>
                  <th className="pb-3 px-2 text-right">Registered On</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-105 dark:divide-slate-800">
                {filteredUsers.length > 0 ? (
                  filteredUsers.map((client) => (
                    <tr key={client.id} className="hover:bg-slate-50/50">
                      <td className="py-3 px-2 font-bold text-slate-800 dark:text-slate-350">{client.name}</td>
                      <td className="py-3 px-2 font-semibold text-slate-505 dark:text-slate-400">{client.email}</td>
                      <td className="py-3 px-2">
                        {client.isAdmin ? (
                          <span className="bg-rose-50 text-rose-700 px-2.5 py-0.5 rounded-full font-bold uppercase tracking-wider text-[9px]">Admin Link</span>
                        ) : (
                          <span className="bg-indigo-50 text-indigo-750 px-2.5 py-0.5 rounded-full font-bold uppercase tracking-wider text-[9px]">Student</span>
                        )}
                      </td>
                      <td className="py-3 px-2 text-right text-slate-400">{new Date(client.created_at).toLocaleDateString()}</td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={4} className="py-12 text-center text-slate-400 italic">No matching candidate accounts found mapped in workspace.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* FORM MODAL FORM FOR QUESTION CREATION AND MODIFICATION */}
      {showForm && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl relative">
            
            {/* Modal header */}
            <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center">
              <h3 className="font-extrabold text-base text-slate-905 dark:text-white flex items-center gap-2">
                <Database className="w-5 h-5 text-indigo-650" />
                {formMode === 'add' ? 'Preseed Custom Question Properties' : 'Modify Question configurations'}
              </h3>
              <button
                type="button"
                onClick={() => setShowForm(false)}
                className="text-slate-400 hover:text-slate-650 p-2 cursor-pointer rounded-xl hover:bg-slate-50"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Form core */}
            <form onSubmit={handleCreateOrEdit} className="p-6 space-y-4 text-xs">
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                
                {/* Category Selection */}
                <div className="space-y-1.5">
                  <label htmlFor="form-category" className="font-bold text-slate-700 dark:text-slate-350">Category Type</label>
                  <select
                    id="form-category"
                    value={categoryField}
                    onChange={(e) => setCategoryField(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-950 text-slate-900 border border-slate-200 rounded-lg p-2.5"
                  >
                    <option value="Technical">Technical</option>
                    <option value="HR">HR Behavioral</option>
                    <option value="Aptitude">Aptitude Numerical</option>
                  </select>
                </div>

                {/* Target Role */}
                <div className="space-y-1.5">
                  <label htmlFor="form-role" className="font-bold text-slate-700 dark:text-slate-350">Job Role Target</label>
                  <select
                    id="form-role"
                    disabled={categoryField !== 'Technical'}
                    value={roleField}
                    onChange={(e) => setRoleField(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-950 text-slate-900 border border-slate-200 rounded-lg p-2.5 disabled:opacity-50"
                  >
                    {[
                      'Web Developer',
                      'Full Stack Developer',
                      'Frontend Developer',
                      'Backend Developer',
                      'Software Engineer',
                      'Data Analyst',
                      'Cybersecurity Analyst',
                      'UI/UX Designer',
                      'Mobile App Developer'
                    ].map(type => (
                      <option key={type} value={type}>{type}</option>
                    ))}
                  </select>
                </div>

                {/* Difficulty Tiers */}
                <div className="space-y-1.5">
                  <label htmlFor="form-difficulty" className="font-bold text-slate-700 dark:text-slate-350">Difficulty Tier</label>
                  <select
                    id="form-difficulty"
                    value={difficultyField}
                    onChange={(e) => setDifficultyField(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-950 text-slate-900 border border-slate-200 rounded-lg p-2.5"
                  >
                    <option value="Beginner">Beginner</option>
                    <option value="Intermediate">Intermediate</option>
                    <option value="Advanced">Advanced</option>
                  </select>
                </div>

                {/* Expected keywords split by comma */}
                <div className="space-y-1.5">
                  <label htmlFor="form-keywords" className="font-bold text-slate-700 dark:text-slate-350">Expected Evaluation Keywords</label>
                  <input
                    id="form-keywords"
                    type="text"
                    value={keywordsField}
                    placeholder="e.g. database, index, b-tree, complexity"
                    onChange={(e) => setKeywordsField(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-950 text-slate-900 border border-slate-200 rounded-lg p-2.5"
                  />
                  <p className="text-[9px] text-slate-400 italic font-medium">Provide values separated strictly by comma (keywords used inside fallback evaluation tags).</p>
                </div>

              </div>

              {/* Question Text */}
              <div className="space-y-1.5">
                <label htmlFor="form-question" className="font-bold text-slate-700 dark:text-slate-350">Question Definition</label>
                <textarea
                  id="form-question"
                  rows={3}
                  value={questionField}
                  onChange={(e) => setQuestionField(e.target.value)}
                  placeholder="Pose the question asked directly onto Maya's avatar interface..."
                  className="w-full bg-slate-50 dark:bg-slate-950 text-slate-900 border border-slate-200 rounded-lg p-2.5 outline-none resize-none font-sans leading-relaxed"
                />
              </div>

              {/* Expected Model Sample Answer */}
              <div className="space-y-1.5">
                <label htmlFor="form-sample-ans" className="font-bold text-slate-700 dark:text-slate-350">Expected Reference Answer Guide</label>
                <textarea
                  id="form-sample-ans"
                  rows={4}
                  value={sampleAnswerField}
                  onChange={(e) => setSampleAnswerField(e.target.value)}
                  placeholder="Insert the official benchmark technical answers context guide..."
                  className="w-full bg-slate-50 dark:bg-slate-950 text-slate-900 border border-slate-200 rounded-lg p-2.5 outline-none resize-none font-mono leading-relaxed"
                />
              </div>

              {/* Actions footer block */}
              <div className="flex justify-end gap-2 pt-4 border-t border-slate-105">
                <button
                  type="button"
                  onClick={() => setShowForm(false)}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold px-4 py-2.5 rounded-lg cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitActive}
                  className="bg-indigo-650 hover:bg-indigo-700 text-white font-black px-5 py-2.5 rounded-lg flex items-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <Save className="w-4 h-4" />
                  {isSubmitActive ? 'Saving Changes...' : 'Commit to Database'}
                </button>
              </div>

            </form>

          </div>
        </div>
      )}

    </div>
  );
}
