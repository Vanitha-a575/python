import React from 'react';
import { DashboardStats, Result } from '../types';
import { Award, Briefcase, Calendar, Clock, Compass, TrendingUp, AlertTriangle, ChevronRight } from 'lucide-react';

interface DashboardProps {
  stats: DashboardStats;
  onViewReport: (resultId: string) => void;
  onNavigateToPractice: () => void;
}

export default function Dashboard({ stats, onViewReport, onNavigateToPractice }: DashboardProps) {
  // Safe default calculations
  const total = stats.totalInterviews || 0;
  const avg = stats.averageScore || 0;
  const best = stats.bestScore || 0;
  const weak = stats.weakestCategory || 'Aptitude';

  // Format date nicely
  const formatDate = (isoStr: string) => {
    return new Date(isoStr).toLocaleDateString(undefined, {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // Safe progress percentages
  const techScore = stats.technicalScore || 0;
  const commScore = stats.communicationScore || 0;
  const confScore = stats.confidenceScore || 0;

  return (
    <div className="space-y-6" id="dashboard-container">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-slate-900 to-indigo-950 text-white rounded-2xl p-6 md:p-8 shadow-sm border border-slate-800 relative overflow-hidden flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div className="relative z-10 space-y-2">
          <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight">Accelerate Your Placement Prep</h1>
          <p className="text-slate-300 text-sm md:text-base max-w-xl">
            Simulate realistic mock interviews with real-time Speech-to-Text and receive instant, personalized AI evaluations with direct study guides.
          </p>
          <div className="pt-2 flex flex-wrap gap-2 text-xs">
            <span className="bg-emerald-500/10 text-emerald-400 px-2.5 py-1 rounded-full border border-emerald-500/20 font-medium">Auto-Grading Active</span>
            <span className="bg-indigo-500/10 text-indigo-400 px-2.5 py-1 rounded-full border border-indigo-500/20 font-medium">9+ Tech Roles Loaded</span>
          </div>
        </div>
        <button
          onClick={onNavigateToPractice}
          id="btn-start-placement"
          className="relative z-10 shrink-0 bg-white hover:bg-slate-100 text-slate-900 px-6 py-3 rounded-xl font-semibold shadow-sm transition-all transform hover:scale-[1.02] active:scale-[0.98] cursor-pointer flex items-center gap-2"
        >
          <Compass className="w-5 h-5 text-indigo-600" />
          Start Mock Session
        </button>
        {/* Subtle decorative background circles */}
        <div className="absolute -right-10 -bottom-10 w-44 h-44 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute right-1/3 -top-12 w-32 h-32 bg-slate-500/10 rounded-full blur-2xl pointer-events-none"></div>
      </div>

      {/* Main Stats Cards Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4" id="stats-grid">
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs hover:shadow-sm transition-all" id="card-total-interviews">
          <div className="flex items-start justify-between">
            <div className="space-y-1">
              <p className="text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider">Total Attempted</p>
              <h3 className="text-2xl md:text-3xl font-bold text-slate-900 dark:text-white">{total}</h3>
            </div>
            <div className="bg-indigo-50 dark:bg-indigo-950/40 p-2.5 rounded-xl border border-indigo-100 dark:border-indigo-900/30">
              <Briefcase className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
            </div>
          </div>
          <div className="mt-4 flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400">
            <span className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-semibold bg-emerald-50 dark:bg-emerald-950/30 px-1.5 py-0.5 rounded">
              Ready
            </span>
            <span>Placement simulations</span>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs hover:shadow-sm transition-all" id="card-average-score">
          <div className="flex items-start justify-between">
            <div className="space-y-1">
              <p className="text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider">Average Score</p>
              <h3 className="text-2xl md:text-3xl font-bold text-slate-900 dark:text-white">{avg}%</h3>
            </div>
            <div className="bg-emerald-50 dark:bg-emerald-950/40 p-2.5 rounded-xl border border-emerald-100 dark:border-emerald-900/30">
              <Award className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
            </div>
          </div>
          <div className="mt-4 flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400">
            <span className={`font-semibold px-1.5 py-0.5 rounded ${avg >= 80 ? 'text-emerald-600 bg-emerald-50' : 'text-amber-600 bg-amber-50'}`}>
              {avg >= 80 ? 'Elite' : avg >= 60 ? 'Competent' : 'Needs practice'}
            </span>
            <span>Overall grading</span>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs hover:shadow-sm transition-all" id="card-best-score">
          <div className="flex items-start justify-between">
            <div className="space-y-1">
              <p className="text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider">Best Score</p>
              <h3 className="text-2xl md:text-3xl font-bold text-slate-900 dark:text-white">{best}%</h3>
            </div>
            <div className="bg-purple-50 dark:bg-purple-950/40 p-2.5 rounded-xl border border-purple-100 dark:border-purple-900/30">
              <TrendingUp className="w-5 h-5 text-purple-600 dark:text-purple-400" />
            </div>
          </div>
          <div className="mt-4 flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400">
            <span className="text-purple-600 font-semibold bg-purple-50 dark:bg-purple-950/30 px-1.5 py-0.5 rounded">
              Peak
            </span>
            <span>Individual score</span>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs hover:shadow-sm transition-all" id="card-weakest-category">
          <div className="flex items-start justify-between">
            <div className="space-y-1">
              <p className="text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider">Weakest Area</p>
              <h3 className="text-2xl md:text-3xl font-bold text-slate-900 dark:text-white">{weak}</h3>
            </div>
            <div className="bg-rose-50 dark:bg-rose-950/40 p-2.5 rounded-xl border border-rose-100 dark:border-rose-900/30">
              <AlertTriangle className="w-5 h-5 text-rose-600 dark:text-rose-400" />
            </div>
          </div>
          <div className="mt-4 flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400">
            <span className="text-rose-600 font-semibold bg-rose-50 dark:bg-rose-950/30 px-1.5 py-0.5 rounded">
              Priority
            </span>
            <span>Recommended focus</span>
          </div>
        </div>
      </div>

      {/* Sub Scores Visual Panels */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="dashboard-details-row">
        {/* Sub-Metric bars */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 flex flex-col justify-between">
          <div className="space-y-1">
            <h4 className="font-bold text-slate-900 dark:text-white text-base">Evaluation Breakdown</h4>
            <p className="text-xs text-slate-500 dark:text-slate-400">Graded indices across placement vectors</p>
          </div>

          <div className="mt-6 space-y-5">
            {/* Technical Score */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-semibold">
                <span className="text-slate-700 dark:text-slate-300">Technical Score</span>
                <span className="text-slate-900 dark:text-white">{techScore}%</span>
              </div>
              <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-2">
                <div
                  className="bg-indigo-600 h-2 rounded-full transition-all duration-500"
                  style={{ width: `${techScore}%` }}
                ></div>
              </div>
            </div>

            {/* Communication Score */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-semibold">
                <span className="text-slate-700 dark:text-slate-300">Communication Score</span>
                <span className="text-slate-900 dark:text-white">{commScore}%</span>
              </div>
              <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-2">
                <div
                  className="bg-emerald-500 h-2 rounded-full transition-all duration-500"
                  style={{ width: `${commScore}%` }}
                ></div>
              </div>
            </div>

            {/* Confidence Score */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-semibold">
                <span className="text-slate-700 dark:text-slate-300">Confidence Score</span>
                <span className="text-slate-900 dark:text-white">{confScore}%</span>
              </div>
              <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-2">
                <div
                  className="bg-purple-600 h-2 rounded-full transition-all duration-500"
                  style={{ width: `${confScore}%` }}
                ></div>
              </div>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-100 dark:border-slate-850 text-xs text-slate-500 dark:text-slate-400 space-y-1.5">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 bg-indigo-650 rounded-full"></span>
              <span>Code logic & technical accuracy</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 bg-emerald-505 rounded-full"></span>
              <span>Language vocabulary, structure & speed</span>
            </div>
          </div>
        </div>

        {/* Dynamic Vector Progress Trends Chart (SVG) */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 col-span-1 lg:col-span-2 space-y-4">
          <div className="flex justify-between items-center">
            <div className="space-y-1">
              <h4 className="font-bold text-slate-900 dark:text-white text-base">Performance Over Time</h4>
              <p className="text-xs text-slate-500 dark:text-slate-400">Score metrics across monthly sessions</p>
            </div>
            <span className="bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 text-xs px-2.5 py-1 rounded-full border border-indigo-100 dark:border-indigo-900/30 font-semibold flex items-center gap-1">
              <TrendingUp className="w-3.5 h-3.5" />
              Success Trend
            </span>
          </div>

          {/* Fallback Graphic / Custom Trend Curve SVG if data empty or valid */}
          <div className="h-48 flex items-center justify-center relative mt-4">
            {stats.monthlyProgress && stats.monthlyProgress.length > 0 ? (
              <div className="w-full h-full flex flex-col justify-between">
                {/* SVG Curve Plot */}
                <div className="relative w-full h-40">
                  <svg className="w-full h-full" viewBox="0 0 500 120" preserveAspectRatio="none">
                    {/* Grid lines */}
                    <line x1="0" y1="30" x2="500" y2="30" stroke="#f1f5f9" strokeDasharray="4 4" className="dark:stroke-slate-800" />
                    <line x1="0" y1="60" x2="500" y2="60" stroke="#f1f5f9" strokeDasharray="4 4" className="dark:stroke-slate-800" />
                    <line x1="0" y1="90" x2="500" y2="90" stroke="#f1f5f9" strokeDasharray="4 4" className="dark:stroke-slate-800" />
                    
                    {/* Score Line */}
                    <path
                      d={stats.monthlyProgress.reduce((acc, step, idx, arr) => {
                        const stepWidth = 500 / Math.max(1, arr.length - 1);
                        const x = idx * stepWidth;
                        // Score 0-100 translated to heights
                        const y = 120 - ((step.score / 100) * 100 + 10);
                        return acc + `${idx === 0 ? 'M' : 'L'} ${x} ${y}`;
                      }, '')}
                      fill="none"
                      stroke="#4f46e5"
                      strokeWidth="3.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />

                    {/* Gradient fill */}
                    <path
                      d={stats.monthlyProgress.reduce((acc, step, idx, arr) => {
                        const stepWidth = 500 / Math.max(1, arr.length - 1);
                        const x = idx * stepWidth;
                        const y = 120 - ((step.score / 100) * 100 + 10);
                        return acc + `${idx === 0 ? 'M' : 'L'} ${x} ${y}`;
                      }, '') + ` L 500 120 L 0 120 Z`}
                      fill="url(#indigo-grad)"
                      opacity="0.15"
                    />

                    <defs>
                      <linearGradient id="indigo-grad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#4f46e5" />
                        <stop offset="100%" stopColor="#4f46e5" stopOpacity="0" />
                      </linearGradient>
                    </defs>

                    {/* Dot indicators */}
                    {stats.monthlyProgress.map((step, idx, arr) => {
                      const stepWidth = 500 / Math.max(1, arr.length - 1);
                      const x = idx * stepWidth;
                      const y = 120 - ((step.score / 100) * 100 + 10);
                      return (
                        <g key={idx} className="group">
                          <circle cx={x} cy={y} r="5" fill="#4f46e5" className="cursor-pointer" />
                          <circle cx={x} cy={y} r="10" fill="#4f46e5" fillOpacity="0.2" className="hidden group-hover:block transition-all" />
                        </g>
                      );
                    })}
                  </svg>
                </div>
                {/* Months display */}
                <div className="flex justify-between text-[10px] md:text-xs font-semibold text-slate-500 dark:text-slate-400 px-2">
                  {stats.monthlyProgress.map((step, idx) => (
                    <div key={idx} className="text-center">
                      <span>{step.month}</span>
                      <span className="block text-[9px] text-[#4f46e5]">({step.score}%)</span>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="text-center rounded-xl p-6 bg-slate-50 dark:bg-slate-900/60 w-full flex flex-col items-center justify-center border border-dashed border-slate-200 dark:border-slate-800">
                <TrendingUp className="w-10 h-10 text-slate-350 mb-2" />
                <span className="text-sm font-medium text-slate-600 dark:text-slate-400">Assessments history empty</span>
                <span className="text-xs text-slate-400 mt-1">Submit your first mock practice report to render analytical trend lines</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Recent History Table Section */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 overflow-hidden">
        <div className="flex justify-between items-center mb-6">
          <div className="space-y-1">
            <h4 className="font-bold text-slate-900 dark:text-white text-base">Recent Practice History</h4>
            <p className="text-xs text-slate-500 dark:text-slate-400">Instant access to complete score reports and feedback</p>
          </div>
          <span className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/40 px-3 py-1 rounded-full">
            {recentHistory.length} Sessions Total
          </span>
        </div>

        {recentHistory.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-100 dark:border-slate-800 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                  <th className="pb-3 pr-4 font-bold">Role Target</th>
                  <th className="pb-3 px-4 font-bold">Type</th>
                  <th className="pb-3 px-4 font-bold">Session Date</th>
                  <th className="pb-3 px-4 font-bold">Quiz Items</th>
                  <th className="pb-3 px-4 font-bold text-right">Overall Grade</th>
                  <th className="pb-3 pl-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-sm">
                {recentHistory.map((item) => (
                  <tr key={item.id} className="group hover:bg-slate-50/50 dark:hover:bg-slate-900/30 transition-all">
                    <td className="py-4 pr-4 font-semibold text-slate-900 dark:text-white flex items-center gap-2">
                      <Briefcase className="w-4 h-4 text-slate-400" />
                      {item.role}
                    </td>
                    <td className="py-4 px-4">
                      <span className={`text-[11px] font-bold px-2 py-0.5 rounded ${
                        item.interview_type === 'Technical' ? 'bg-indigo-50 text-indigo-600 dark:bg-indigo-950/40 dark:text-indigo-400' :
                        item.interview_type === 'HR' ? 'bg-purple-50 text-purple-650 dark:bg-purple-950/40 dark:text-purple-400' :
                        'bg-amber-50 text-amber-650 dark:bg-amber-950/40 dark:text-amber-400'
                      }`}>
                        {item.interview_type}
                      </span>
                    </td>
                    <td className="py-4 px-4 text-slate-500 dark:text-slate-400 text-xs flex-nowrap">
                      <div className="flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5" />
                        {formatDate(item.date)}
                      </div>
                    </td>
                    <td className="py-4 px-4 text-slate-500 dark:text-slate-400">
                      {item.questions_count} Questions
                    </td>
                    <td className="py-4 px-4 text-right font-bold">
                      <span className={`px-2 py-0.5 rounded text-xs ${
                        item.overall_score >= 80 ? 'text-emerald-700 bg-emerald-50 dark:text-emerald-400 dark:bg-emerald-950/20' :
                        item.overall_score >= 60 ? 'text-amber-700 bg-amber-50 dark:text-amber-400 dark:bg-amber-950/20' :
                        'text-rose-700 bg-rose-50 dark:text-rose-450 dark:bg-rose-950/20'
                      }`}>
                        {item.overall_score}%
                      </span>
                    </td>
                    <td className="py-4 pl-4 text-right">
                      <button
                        onClick={() => onViewReport(`r-${item.id}`)}
                        id={`btn-view-${item.id}`}
                        className="text-xs font-bold text-indigo-600 hover:text-indigo-800 dark:text-indigo-400 dark:hover:text-indigo-300 transition-colors flex items-center gap-1 ml-auto cursor-pointer"
                      >
                        View Report
                        <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="text-center py-12 flex flex-col items-center justify-center bg-slate-50 dark:bg-slate-900/40 rounded-2xl border border-dashed border-slate-200 dark:border-slate-850">
            <Clock className="w-12 h-12 text-slate-300 mb-2" />
            <span className="text-sm font-semibold text-slate-650 dark:text-slate-400">No session recordings yet</span>
            <span className="text-xs text-slate-400 mt-1 max-w-sm mb-4">You have not completed any interview practices. Tap below to launch your first training simulation!</span>
            <button
              onClick={onNavigateToPractice}
              id="btn-trigger-quiz"
              className="bg-indigo-650 text-white px-5 py-2.5 rounded-xl font-bold hover:bg-indigo-700 cursor-pointer text-xs"
            >
              Launch First Practice
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
