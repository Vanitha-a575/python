import React, { useState } from 'react';
import { Briefcase, Settings, Mic, Keyboard, Timer, Play } from 'lucide-react';

interface PracticeSettingsProps {
  onStartInterview: (config: {
    role: string;
    interview_type: string;
    difficulty: string;
    questionCount: number;
    timer: number;
    mode: 'voice' | 'text';
  }) => void;
  isStarting: boolean;
}

export default function PracticeSettings({ onStartInterview, isStarting }: PracticeSettingsProps) {
  const [role, setRole] = useState('Web Developer');
  const [interviewType, setInterviewType] = useState('Technical');
  const [difficulty, setDifficulty] = useState('Intermediate');
  const [questionCount, setQuestionCount] = useState(5);
  const [timer, setTimer] = useState(60); // 60 seconds per question
  const [mode, setMode] = useState<'voice' | 'text'>('text');

  const rolesList = [
    'Web Developer',
    'Full Stack Developer',
    'Frontend Developer',
    'Backend Developer',
    'Software Engineer',
    'Data Analyst',
    'Cybersecurity Analyst',
    'UI/UX Designer',
    'Mobile App Developer'
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onStartInterview({
      role,
      interview_type: interviewType,
      difficulty,
      questionCount,
      timer,
      mode
    });
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6" id="settings-container">
      <div className="space-y-1">
        <h2 className="text-2xl font-bold text-slate-900 dark:text-white tracking-tight">Configure Interview Arena</h2>
        <p className="text-sm text-slate-500 dark:text-slate-400">Set up the domain, timers, and assessment mode to begin your practice run.</p>
      </div>

      <form onSubmit={handleSubmit} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xs overflow-hidden">
        <div className="p-6 md:p-8 space-y-6">
          {/* Step 1: Broad Category Select */}
          <div className="space-y-3">
            <label className="text-sm font-bold text-slate-850 dark:text-slate-300 block">1. Select Interview Category</label>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {[
                { name: 'Technical', desc: 'Focus specifically on role concepts, architecture, and syntax.' },
                { name: 'HR', desc: 'Assess interpersonal skills, cultural fit, and STAR scenario responses.' },
                { name: 'Mock Placement', desc: 'Simulation representing a real company hiring cycle (Combined Tech, HR & Aptitude).' }
              ].map((type) => (
                <div
                  key={type.name}
                  onClick={() => setInterviewType(type.name)}
                  className={`border rounded-xl p-4 cursor-pointer transition-all ${
                    interviewType === type.name
                      ? 'border-indigo-650 bg-indigo-50/25 dark:bg-indigo-950/20 dark:border-indigo-500'
                      : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 bg-slate-50/50 dark:bg-slate-900/60'
                  }`}
                >
                  <p className="font-bold text-sm text-slate-900 dark:text-white mb-1">{type.name}</p>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">{type.desc}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Step 2: Role Selection */}
            <div className="space-y-1.5">
              <label htmlFor="select-role-list" className="text-sm font-bold text-slate-850 dark:text-slate-300 flex items-center gap-1.5">
                <Briefcase className="w-4 h-4 text-slate-400" />
                Target Job Role
              </label>
              <select
                id="select-role-list"
                value={role}
                onChange={(e) => setRole(e.target.value)}
                disabled={interviewType === 'HR'}
                className="w-full bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-3 text-sm focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all outline-none disabled:opacity-50"
              >
                {rolesList.map((r) => (
                  <option key={r} value={r}>{r}</option>
                ))}
              </select>
              {interviewType === 'HR' && (
                <p className="text-[10px] text-indigo-600 dark:text-indigo-400 font-semibold italic">Not required for pure HR behavioral assessments</p>
              )}
            </div>

            {/* Step 3: Difficulty Selection */}
            <div className="space-y-1.5">
              <label className="text-sm font-bold text-slate-850 dark:text-slate-300 block">Difficulty Level</label>
              <div className="grid grid-cols-3 gap-2">
                {['Beginner', 'Intermediate', 'Advanced'].map((level) => (
                  <button
                    key={level}
                    type="button"
                    onClick={() => setDifficulty(level)}
                    className={`text-xs font-bold py-3 px-3 rounded-xl border transition-all cursor-pointer ${
                      difficulty === level
                        ? 'border-indigo-600 bg-indigo-600 text-white dark:border-indigo-500'
                        : 'border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 bg-slate-50/50 dark:bg-slate-950 hover:bg-slate-100'
                    }`}
                  >
                    {level}
                  </button>
                ))}
              </div>
            </div>

            {/* Step 4: Question Count Selection */}
            <div className="space-y-1.5">
              <label htmlFor="select-question-count" className="text-sm font-bold text-slate-850 dark:text-slate-300 block">Question Pool Size</label>
              <select
                id="select-question-count"
                value={questionCount}
                onChange={(e) => setQuestionCount(parseInt(e.target.value))}
                className="w-full bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-3 text-sm focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none transition-all"
              >
                {[3, 4, 5, 7, 10].map((num) => (
                  <option key={num} value={num}>{num} Questions</option>
                ))}
              </select>
            </div>

            {/* Step 5: Countdown Timers */}
            <div className="space-y-1.5">
              <label htmlFor="select-timer" className="text-sm font-bold text-slate-850 dark:text-slate-300 flex items-center gap-1.5">
                <Timer className="w-4 h-4 text-slate-400" />
                Response Time Limit
              </label>
              <select
                id="select-timer"
                value={timer}
                onChange={(e) => setTimer(parseInt(e.target.value))}
                className="w-full bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-3 text-sm focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none transition-all"
              >
                <option value={30}>30 seconds / question</option>
                <option value={45}>45 seconds / question</option>
                <option value={60}>60 seconds / question</option>
                <option value={90}>90 seconds / question</option>
                <option value={120}>120 seconds / question</option>
              </select>
            </div>
          </div>

          {/* Step 6: Mode Selection (Voice vs Text input) */}
          <div className="space-y-3 pt-2">
            <label className="text-sm font-bold text-slate-850 dark:text-slate-300 block">Interaction Mode</label>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div
                onClick={() => setMode('text')}
                className={`border rounded-xl p-4 cursor-pointer transition-all flex items-start gap-3 ${
                  mode === 'text'
                    ? 'border-indigo-650 bg-indigo-50/25 dark:bg-indigo-950/20 dark:border-indigo-500'
                    : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 bg-slate-50/50 dark:bg-slate-900/60'
                }`}
              >
                <div className="bg-white dark:bg-slate-950 p-2.5 rounded-lg border border-slate-200 dark:border-slate-850">
                  <Keyboard className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                </div>
                <div className="space-y-0.5">
                  <p className="font-bold text-sm text-slate-900 dark:text-white">Keyboard Text Entry</p>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                    Formulate written answers sequentially. Standard timer counts down while you draft and verify.
                  </p>
                </div>
              </div>

              <div
                onClick={() => setMode('voice')}
                className={`border rounded-xl p-4 cursor-pointer transition-all flex items-start gap-3 ${
                  mode === 'voice'
                    ? 'border-indigo-650 bg-indigo-50/25 dark:bg-indigo-950/20 dark:border-indigo-500'
                    : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 bg-slate-50/50 dark:bg-slate-900/60'
                }`}
              >
                <div className="bg-white dark:bg-slate-950 p-2.5 rounded-lg border border-slate-200 dark:border-slate-850">
                  <Mic className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                </div>
                <div className="space-y-0.5">
                  <p className="font-bold text-sm text-slate-900 dark:text-white">Speech Voice Recognition</p>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                    Utilizes HTML5 webkitSpeechRecognition API. Dictate, view real-time transcribed text, edit draft, and submit.
                  </p>
                </div>
              </div>
            </div>
            {mode === 'voice' && (
              <p className="text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold bg-emerald-50 dark:bg-emerald-950/30 px-3 py-1.5 rounded-lg border border-emerald-100 dark:border-emerald-900/30">
                Note: Standard Web speech recognition requests microphone access in your iframe layout. Be sure to accept the prompt when voice actions boot!
              </p>
            )}
          </div>
        </div>

        {/* Start Button */}
        <div className="bg-slate-50 dark:bg-slate-950 border-t border-slate-250 dark:border-slate-800 px-6 py-4 flex justify-between items-center">
          <div className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1">
            <Settings className="w-4 h-4 animate-spin-slow text-slate-400" />
            Randomly compiling from selected pools...
          </div>
          <button
            type="submit"
            disabled={isStarting}
            id="btn-confirm-settings"
            className="bg-indigo-650 hover:bg-indigo-700 text-white font-bold px-6 py-3 rounded-xl shadow-xs transition-all flex items-center gap-2 cursor-pointer text-sm transform hover:scale-[1.01] active:scale-[0.99] disabled:opacity-50"
          >
            {isStarting ? (
              <>
                <svg className="animate-spin h-4 w-4 text-white" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                </svg>
                Creating Session...
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-white" />
                Initialize Practice Arena
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
}
