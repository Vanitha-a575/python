import React, { useState } from 'react';
import { User, Lock, Key, Brush, Save } from 'lucide-react';

interface ProfileProps {
  user: { id: string; name: string; email: string; profile_image?: string };
  onUpdateValue: (name: string, profile_image: string) => Promise<void>;
  onChangePasswordValue: (current: string, next: string, confirm: string) => Promise<void>;
  successMessageProp?: string;
  errorMessageProp?: string;
}

export default function Profile({ user, onUpdateValue, onChangePasswordValue }: ProfileProps) {
  const [name, setName] = useState(user.name);
  const [profileImage, setProfileImage] = useState(user.profile_image || '');

  // Safety message indicators
  const [notiText, setNotiText] = useState('');
  const [errText, setErrText] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  // Security elements
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');

  const avatarPresets = [
    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
    'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150',
    'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150',
    'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
    'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150'
  ];

  const handleProfileSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    setNotiText('');
    setErrText('');

    try {
      await onUpdateValue(name, profileImage);
      setNotiText('Success announcement: Placement profile records saved successfully.');
    } catch (err: any) {
      setErrText(err.message || 'Validation error: Failed to update profile attributes.');
    } finally {
      setIsSaving(false);
    }
  };

  const handlePasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    setNotiText('');
    setErrText('');

    if (newPassword !== confirmNewPassword) {
      setErrText('Validation notice: Confirm password does not match with the chosen new password.');
      setIsSaving(false);
      return;
    }

    try {
      await onChangePasswordValue(currentPassword, newPassword, confirmNewPassword);
      setNotiText('Success announcement: Profile security credentials updated successfully!');
      setCurrentPassword('');
      setNewPassword('');
      setConfirmNewPassword('');
    } catch (err: any) {
      setErrText(err.message || 'Security error: Failed to change password. Please verify current credentials.');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6" id="profile-container">
      
      <div className="space-y-1">
        <h2 className="text-2xl font-bold text-slate-900 dark:text-white tracking-tight">Personal Profile Settings</h2>
        <p className="text-sm text-slate-500 dark:text-slate-400">Configure your placement credentials, choose assessment avatars, and manage portal passwords.</p>
      </div>

      {notiText && (
        <div className="bg-emerald-50 dark:bg-emerald-950/20 text-emerald-700 dark:text-emerald-400 border border-emerald-100 dark:border-emerald-900/40 p-4 rounded-xl text-xs font-semibold">
          {notiText}
        </div>
      )}

      {errText && (
        <div className="bg-rose-50 dark:bg-rose-950/20 text-rose-700 dark:text-rose-400 border border-rose-100 dark:border-rose-900/40 p-4 rounded-xl text-xs font-semibold">
          {errText}
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* 1. Profile information editing */}
        <form onSubmit={handleProfileSubmit} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 md:p-8 space-y-6 flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex items-center gap-2 border-b border-slate-100 dark:border-slate-850 pb-3">
              <User className="w-5 h-5 text-indigo-550" />
              <h3 className="font-bold text-slate-900 dark:text-white text-base">Portal Profile Details</h3>
            </div>

            {/* Avatar display preset */}
            <div className="flex items-center gap-4">
              <img
                src={profileImage || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150'}
                alt="Account Avatar"
                className="w-16 h-16 rounded-full border-2 border-indigo-500 object-cover"
              />
              <div className="space-y-1.5 grow">
                <span className="text-xs font-bold text-slate-600 dark:text-slate-400 block flex items-center gap-1">
                  <Brush className="w-3.5 h-3.5" /> Select Avatar Preset
                </span>
                <div className="flex gap-1.5 flex-wrap">
                  {avatarPresets.map((av, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setProfileImage(av)}
                      className={`w-8 h-8 rounded-full overflow-hidden border-2 transition-all cursor-pointer ${
                        profileImage === av ? 'border-indigo-600 scale-108' : 'border-slate-200 opacity-60 hover:opacity-100'
                      }`}
                    >
                      <img src={av} alt="Preset visual" className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Name Input */}
            <div className="space-y-1.5">
              <label htmlFor="pf-input-name" className="text-xs font-bold text-slate-650 dark:text-slate-350 block">Name</label>
              <input
                id="pf-input-name"
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-3 text-sm focus:border-indigo-505 outlined-none transition-all"
              />
            </div>

            {/* Email (Readonly) */}
            <div className="space-y-1.5">
              <label htmlFor="pf-input-email" className="text-xs font-bold text-slate-650 dark:text-slate-350 block">Registered Email address</label>
              <input
                id="pf-input-email"
                type="email"
                readOnly
                value={user.email}
                className="w-full bg-slate-100 dark:bg-slate-950/60 text-slate-500 border border-slate-200 dark:border-slate-850 rounded-xl px-4 py-3 text-sm cursor-not-allowed"
              />
              <p className="text-[10px] text-slate-400 leading-relaxed italic">Email addresses are unique anchors for credential matching and cannot be modified.</p>
            </div>
          </div>

          <button
            type="submit"
            disabled={isSaving}
            className="w-full bg-indigo-650 hover:bg-indigo-700 text-white font-extrabold py-3 rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-sm transition-all cursor-pointer mt-4"
          >
            <Save className="w-4 h-4" />
            {isSaving ? 'Saving Changes...' : 'Update Details'}
          </button>
        </form>

        {/* 2. Security / Password update */}
        <form onSubmit={handlePasswordSubmit} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 md:p-8 space-y-6 flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex items-center gap-2 border-b border-slate-100 dark:border-slate-850 pb-3">
              <Lock className="w-5 h-5 text-indigo-550" />
              <h3 className="font-bold text-slate-900 dark:text-white text-base">Change Secure Password</h3>
            </div>

            {/* Current Password */}
            <div className="space-y-1.5">
              <label htmlFor="pf-input-current-pass" className="text-xs font-bold text-slate-650 dark:text-slate-350 block">Current Password</label>
              <input
                id="pf-input-current-pass"
                type="password"
                required
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-3 text-sm focus:border-indigo-505 outline-none"
              />
            </div>

            {/* New Password */}
            <div className="space-y-1.5">
              <label htmlFor="pf-input-new-pass" className="text-xs font-bold text-slate-650 dark:text-slate-350 block">New Security Password</label>
              <input
                id="pf-input-new-pass"
                type="password"
                required
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-3 text-sm focus:border-indigo-505 outline-none"
              />
            </div>

            {/* Confirm New Password */}
            <div className="space-y-1.5">
              <label htmlFor="pf-input-confirm-pass" className="text-xs font-bold text-slate-650 dark:text-slate-350 block">Confirm New Password</label>
              <input
                id="pf-input-confirm-pass"
                type="password"
                required
                value={confirmNewPassword}
                onChange={(e) => setConfirmNewPassword(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-3 text-sm focus:border-indigo-505 use-none"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={isSaving}
            className="w-full bg-slate-900 hover:bg-slate-850 dark:bg-indigo-650 dark:hover:bg-indigo-700 text-white font-extrabold py-3 rounded-xl text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer mt-4"
          >
            <Key className="w-4 h-4" />
            {isSaving ? 'Updating Key...' : 'Verify & Change Password'}
          </button>
        </form>

      </div>
    </div>
  );
}
