import React, { useState, useEffect, useRef } from 'react';
import { Award, Clock, HelpCircle, ArrowRight, Mic, MicOff, RefreshCw, Send, Sparkles, User, AlertCircle } from 'lucide-react';
import { AnswerEvaluation } from '../types';

interface LiveArenaProps {
  interviewData: {
    id: string;
    role: string;
    interview_type: string;
    difficulty: string;
    time_settings: number;
    mode: 'voice' | 'text';
    questions: Array<{ id: string; category: string; question: string; difficulty: string }>;
  };
  onEvaluateQuestion: (questionId: string, userAnswer: string, timeTaken: number) => Promise<AnswerEvaluation>;
  onCompleteInterview: (interviewId: string) => void;
}

export default function LiveArena({ interviewData, onEvaluateQuestion, onCompleteInterview }: LiveArenaProps) {
  const [currentIdx, setCurrentIdx] = useState(0);
  const [answerText, setAnswerText] = useState('');
  const [timeTaken, setTimeTaken] = useState(0);
  const [timeLeft, setTimeLeft] = useState(interviewData.time_settings);
  const [isRecording, setIsRecording] = useState(false);
  const [evaluation, setEvaluation] = useState<AnswerEvaluation | null>(null);
  const [isValidating, setIsValidating] = useState(false);
  const [errorWord, setErrorWord] = useState('');
  
  // Ref pointers to manage timers safely across transitions
  const qTimerRef = useRef<NodeJS.Timeout | null>(null);
  const timeTakenRef = useRef<number>(0);
  const speechRecognitionRef = useRef<any>(null);

  const currentQuestion = interviewData.questions[currentIdx];
  const isLastQuestion = currentIdx === interviewData.questions.length - 1;

  // Track timer count down
  useEffect(() => {
    // Reset timer on question change
    setTimeLeft(interviewData.time_settings);
    setTimeTaken(0);
    timeTakenRef.current = 0;
    setAnswerText('');
    setEvaluation(null);
    setErrorWord('');

    // Stop recording if active
    if (isRecording) {
      stopSpeechRecognition();
    }

    if (qTimerRef.current) clearInterval(qTimerRef.current);

    qTimerRef.current = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          // Time expired! Auto submit current answer
          clearInterval(qTimerRef.current!);
          handleAutoSubmitOnTimeout();
          return 0;
        }
        return prev - 1;
      });
      setTimeTaken((prev) => {
        timeTakenRef.current = prev + 1;
        return prev + 1;
      });
    }, 1000);

    return () => {
      if (qTimerRef.current) clearInterval(qTimerRef.current);
    };
  }, [currentIdx]);

  // Handle initialization of Web HTML5 Speech API is available
  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      const rec = new SpeechRecognition();
      rec.continuous = true;
      rec.interimResults = true;
      rec.lang = 'en-US';

      rec.onresult = (event: any) => {
        let interimTranscript = '';
        let finalTranscript = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript;
          } else {
            interimTranscript += event.results[i][0].transcript;
          }
        }

        // Output results to editable text state
        if (finalTranscript) {
          setAnswerText((prev) => prev + (prev.endsWith(' ') || prev.length === 0 ? '' : ' ') + finalTranscript);
        }
      };

      rec.onend = () => {
        setIsRecording(false);
      };

      rec.onerror = (err: any) => {
        console.error('Speech recognition error encountered:', err);
        setErrorWord(`Speech input notice: ${err.error || 'Failed to capture voice'}`);
        setIsRecording(false);
      };

      speechRecognitionRef.current = rec;
    } else {
      console.log('Web SpeechRecognition API not supported on this platform/browser.');
    }

    return () => {
      if (speechRecognitionRef.current) {
        try {
          speechRecognitionRef.current.stop();
        } catch (e) {}
      }
    };
  }, []);

  const startSpeechRecognition = () => {
    if (!speechRecognitionRef.current) {
      setErrorWord('Speech recognition helper not available in this browser. Please type your responses.');
      return;
    }
    setErrorWord('');
    try {
      speechRecognitionRef.current.start();
      setIsRecording(true);
    } catch (e) {
      console.error(e);
    }
  };

  const stopSpeechRecognition = () => {
    if (speechRecognitionRef.current) {
      try {
        speechRecognitionRef.current.stop();
        setIsRecording(false);
      } catch (e) {}
    }
  };

  const handleAutoSubmitOnTimeout = () => {
    setErrorWord('Session announcement: Time allowed expired! Auto compiling current drafts...');
    submitCurrentResponse();
  };

  const submitCurrentResponse = async () => {
    // Prevent double validations
    if (isValidating) return;

    if (qTimerRef.current) clearInterval(qTimerRef.current);
    if (isRecording) stopSpeechRecognition();

    setIsValidating(true);
    setErrorWord('');

    const answerToEvaluate = answerText.trim() || '[No submission provided - Timeout or Skip]';
    const computedTime = timeTakenRef.current || 1;

    try {
      const evalResponse = await onEvaluateQuestion(currentQuestion.id, answerToEvaluate, computedTime);
      setEvaluation(evalResponse);
    } catch (err: any) {
      console.error('Answer evaluation failed:', err);
      setErrorWord('Submission error: Network error when grading response. Please review.');
    } finally {
      setIsValidating(false);
    }
  };

  const proceedToNext = () => {
    if (isLastQuestion) {
      // Completed full quiz!
      onCompleteInterview(interviewData.id);
    } else {
      setCurrentIdx((prev) => prev + 1);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch" id="live-arena-root">
      
      {/* 1. Left side Interviewer panel */}
      <div className="lg:col-span-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 flex flex-col justify-between space-y-6 relative overflow-hidden" id="interviewer-panel">
        
        {/* Header stats */}
        <div className="flex justify-between items-center bg-slate-50 dark:bg-slate-950 p-3 rounded-xl border border-slate-100 dark:border-slate-850">
          <span className="text-xs text-slate-500 dark:text-slate-400 font-bold flex items-center gap-1">
            <HelpCircle className="w-3.5 h-3.5 text-indigo-500" />
            Active: {currentIdx + 1} / {interviewData.questions.length}
          </span>
          <span className={`text-xs font-bold flex items-center gap-1 ${
            timeLeft <= 10 ? 'text-rose-600 animate-pulse' : 'text-slate-600 dark:text-slate-400'
          }`}>
            <Clock className="w-3.5 h-3.5" />
            {timeLeft}s remaining
          </span>
        </div>

        {/* Interviewer Display character */}
        <div className="flex flex-col items-center text-center space-y-4 py-4 relative z-10">
          {/* Animated Avatar circle container */}
          <div className="relative">
            <div className={`w-28 h-28 rounded-full bg-gradient-to-tr from-indigo-500 to-purple-600 p-1 relative flex items-center justify-center shadow-lg transition-transform duration-300 ${
              isRecording ? 'scale-105 ring-4 ring-emerald-500/30' : isValidating ? 'animate-pulse' : 'hover:scale-102'
            }`}>
              <div className="w-full h-full rounded-full bg-slate-900 overflow-hidden relative flex items-center justify-center">
                {/* Simulated cartoon agent with vector patterns */}
                <User className="w-16 h-16 text-indigo-200 mt-2" />
                {/* Talking animation bars if Grading or listening */}
                {(isRecording || isValidating) && (
                  <div className="absolute inset-0 bg-slate-950/70 flex items-center justify-center gap-1">
                    <span className="w-1 h-6 bg-indigo-500 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></span>
                    <span className="w-1 h-8 bg-purple-500 rounded-full animate-bounce" style={{ animationDelay: '0.3s' }}></span>
                    <span className="w-1 h-6 bg-indigo-500 rounded-full animate-bounce" style={{ animationDelay: '0.5s' }}></span>
                  </div>
                )}
              </div>
            </div>
            <span className="absolute bottom-1 right-1 bg-indigo-600 text-[10px] text-white px-2 py-0.5 rounded-full font-extrabold shadow-sm border border-white">
              AI Maya
            </span>
          </div>

          <div className="space-y-1">
            <h4 className="font-bold text-slate-900 dark:text-white text-sm">Maya - Head of Placement</h4>
            <p className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">AI Interactive Recruiter</p>
          </div>

          {/* Prompt speech bubble */}
          <div className="bg-slate-50 dark:bg-slate-950 border border-slate-150 dark:border-slate-850 rounded-2xl p-4 text-xs text-slate-700 dark:text-slate-300 relative w-full leading-relaxed shadow-xs" id="speech-bubble">
            <span className="absolute -top-2 left-1/2 transform -translate-x-1/2 w-3.5 h-3.5 bg-slate-50 dark:bg-slate-950 border-t border-l border-slate-150 dark:border-slate-850 rotate-45"></span>
            <p className="font-semibold text-slate-900 dark:text-white mb-1">Maya:</p>
            "{currentQuestion.question}"
          </div>
        </div>

        {/* Progress bar line indicators */}
        <div className="space-y-1">
          <div className="w-full bg-slate-100 dark:bg-slate-950 h-1.5 rounded-full overflow-hidden">
            <div
              className="bg-indigo-600 h-1.5 rounded-full transition-all duration-300"
              style={{ width: `${((currentIdx + 1) / interviewData.questions.length) * 100}%` }}
            ></div>
          </div>
          <div className="flex justify-between text-[10px] text-slate-400 font-bold">
            <span>Interview progression</span>
            <span>{Math.round(((currentIdx + 1) / interviewData.questions.length) * 100)}%</span>
          </div>
        </div>
      </div>

      {/* 2. Right side Candidate Answer box options */}
      <div className="lg:col-span-7 flex flex-col justify-between bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 relative overflow-hidden" id="workspace-panel">
        
        {/* Workspace state header */}
        <div className="space-y-1 mb-4">
          <span className="bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 text-[10px] px-2.5 py-1 rounded-full font-bold border border-indigo-100 dark:border-indigo-900/30">
            {currentQuestion.category} Assessment
          </span>
          <h3 className="text-lg font-bold text-slate-900 dark:text-white">Candidate Solution Workspace</h3>
        </div>

        {/* Main Textarea drafting */}
        <div className="grow flex flex-col space-y-4">
          <div className="relative grow min-h-48 flex flex-col">
            <textarea
              disabled={evaluation !== null || isValidating}
              value={answerText}
              onChange={(e) => setAnswerText(e.target.value)}
              placeholder={
                interviewData.mode === 'voice'
                  ? "Click the 'Start Recording' button to speak your answer, or type directly here if you prefer..."
                  : "Type your thorough response to Maya here. Be sure to address core concepts and expected keywords..."
              }
              id="candidate-response-input"
              className="w-full grow min-h-48 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-850 p-4 rounded-xl text-sm outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all font-sans leading-relaxed resize-none disabled:opacity-85 disabled:cursor-not-allowed"
            />
            {isRecording && (
              <span className="absolute bottom-3 right-3 flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
              </span>
            )}
          </div>

          {/* Action and feedback controls */}
          <div className="flex flex-wrap gap-2 justify-between items-center pt-2">
            
            {/* Left side actions (Mic controls for voice sessions) */}
            <div className="flex items-center gap-2">
              {interviewData.mode === 'voice' && (
                <>
                  {!isRecording ? (
                    <button
                      type="button"
                      disabled={evaluation !== null || isValidating}
                      onClick={startSpeechRecognition}
                      id="btn-voice-record-start"
                      className="bg-emerald-500 hover:bg-emerald-600 disabled:opacity-40 text-white font-bold px-4 py-2.5 rounded-xl text-xs flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
                    >
                      <Mic className="w-4 h-4" />
                      Start Dictation
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={stopSpeechRecognition}
                      id="btn-voice-record-stop"
                      className="bg-red-550 hover:bg-red-650 text-white font-bold px-4 py-2.5 rounded-xl text-xs flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
                    >
                      <MicOff className="w-4 h-4 animate-pulse" />
                      Stop Listening
                    </button>
                  )}
                </>
              )}
              {answerText.length > 0 && !evaluation && (
                <button
                  type="button"
                  disabled={isValidating}
                  onClick={() => setAnswerText('')}
                  className="bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold p-2.5 rounded-xl text-xs transition-all cursor-pointer"
                  title="Reset drafted inputs"
                >
                  <RefreshCw className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Right side primary action */}
            {!evaluation && (
              <button
                type="button"
                disabled={isValidating}
                onClick={submitCurrentResponse}
                id="btn-submit-answer"
                className="bg-indigo-650 hover:bg-indigo-700 disabled:opacity-50 text-white font-extrabold px-5 py-2.5 rounded-xl text-xs flex items-center gap-1.5 transition-all cursor-pointer shadow-xs"
              >
                {isValidating ? (
                  <>
                    <svg className="animate-spin h-4 w-4 text-white" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                    </svg>
                    Maya is Grading...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 text-amber-300 fill-amber-300" />
                    Evaluate Draft
                    <Send className="w-3.5 h-3.5 ml-1" />
                  </>
                )}
              </button>
            )}
          </div>
        </div>

        {/* Notices and warnings block */}
        {errorWord && (
          <div className="mt-4 bg-amber-50 dark:bg-amber-950/20 text-amber-700 dark:text-amber-400 border border-amber-200 dark:border-amber-900/40 p-3.5 rounded-xl text-xs flex items-start gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <p className="leading-relaxed">{errorWord}</p>
          </div>
        )}

        {/* Real-time AI evaluation response box block */}
        {evaluation && (
          <div className="mt-6 bg-indigo-50/40 dark:bg-slate-950 border border-indigo-100 dark:border-indigo-900/50 rounded-2xl p-4 space-y-4 shadow-inner" id="live-grading-card">
            <div className="flex justify-between items-center border-b border-indigo-100/50 dark:border-indigo-950 pb-2">
              <div className="flex items-center gap-1.5">
                <Award className="w-4 h-4 text-indigo-650" />
                <span className="text-xs font-bold text-indigo-900 dark:text-indigo-400 uppercase tracking-wider">AI Evaluation Grade</span>
              </div>
              <div className="bg-indigo-600 text-white font-extrabold text-sm px-3 py-1 rounded-lg">
                Score: {evaluation.score}/100
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div className="space-y-1.5">
                <span className="font-bold text-slate-800 dark:text-slate-300 block">Strengths</span>
                <ul className="list-disc list-inside space-y-1 text-slate-600 dark:text-slate-400 pl-1">
                  {evaluation.strengths.slice(0, 2).map((st, idx) => (
                    <li key={idx} className="leading-relaxed">{st}</li>
                  ))}
                </ul>
              </div>

              <div className="space-y-1.5">
                <span className="font-bold text-slate-800 dark:text-slate-300 block">Actions for Improvement</span>
                <ul className="list-disc list-inside space-y-1 text-slate-605 dark:text-slate-400 pl-1">
                  {evaluation.suggestions.slice(0, 2).map((su, idx) => (
                    <li key={idx} className="leading-relaxed">{su}</li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Keyword tag matching visualization */}
            {evaluation.keywordCoverage && (
              <div className="pt-2 border-t border-indigo-100/30 dark:border-indigo-950 text-xs flex flex-wrap gap-2 items-center">
                <span className="font-bold text-slate-800 dark:text-slate-300">Keywords covered:</span>
                {evaluation.keywordCoverage.covered.length > 0 ? (
                  evaluation.keywordCoverage.covered.map((tag) => (
                    <span key={tag} className="bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400 border border-emerald-100 dark:border-emerald-900/20 px-2 py-0.5 rounded text-[10px] font-semibold">
                      ✓ {tag}
                    </span>
                  ))
                ) : (
                  <span className="text-[10px] text-slate-400 italic">None logged</span>
                )}
              </div>
            )}

            {/* Proceed Actions */}
            <div className="pt-2 flex justify-end">
              <button
                type="button"
                onClick={proceedToNext}
                id="btn-proceed-next"
                className="bg-indigo-650 hover:bg-indigo-700 text-white text-xs font-bold px-4 py-2 rounded-xl flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors"
              >
                {isLastQuestion ? 'Complete Assessment' : 'Next Question'}
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
