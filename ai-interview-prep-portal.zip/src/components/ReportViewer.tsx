import React from 'react';
import { Result, Interview } from '../types';
import { Award, CheckCircle, AlertTriangle, Lightbulb, Compass, ArrowLeft, Printer, RefreshCw, Key, ChevronRight } from 'lucide-react';

interface ReportViewerProps {
  reportData: {
    result: Result;
    interview: Interview;
  };
  onBackToDashboard: () => void;
  onRestartPractice: () => void;
}

export default function ReportViewer({ reportData, onBackToDashboard, onRestartPractice }: ReportViewerProps) {
  const { result, interview } = reportData;

  const handlePrint = () => {
    window.print();
  };

  // Safe averages
  const scoreOverall = result.overall_score || 0;
  const scoreTech = result.technical_score || 0;
  const scoreComm = result.communication_score || 0;
  const scoreConf = result.confidence_score || 0;

  return (
    <div className="space-y-6" id="report-view-root">
      
      {/* Header controls */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
        <div className="space-y-1">
          <button
            onClick={onBackToDashboard}
            className="text-xs font-semibold text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-amber-200 transition-colors flex items-center gap-1 cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Dashboard
          </button>
          <h2 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">Placement Performance Appraisal</h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">Assessed on {new Date(result.date).toLocaleDateString()} for target Job: {result.role}</p>
        </div>

        <div className="flex gap-2 shrink-0">
          <button
            onClick={handlePrint}
            className="border border-slate-200 dark:border-slate-850 hover:bg-slate-50 dark:hover:bg-slate-900 text-slate-700 dark:text-slate-300 font-bold px-4 py-2.5 rounded-xl text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            Print / Download
          </button>
          <button
            onClick={onRestartPractice}
            className="bg-indigo-650 hover:bg-indigo-700 text-white font-extrabold px-4 py-2.5 rounded-xl text-xs flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
          >
            <RefreshCw className="w-4 h-4" />
            New Interview Practice
          </button>
        </div>
      </div>

      {/* Main score metrics banner */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4" id="scorecard-grid">
        
        {/* Overall large circle gauge */}
        <div className="bg-gradient-to-br from-indigo-950 to-slate-900 rounded-2xl p-6 border border-slate-800 text-white flex flex-col justify-between items-center text-center">
          <span className="text-xs font-bold uppercase tracking-widest text-[#4f46e5]">Overall Competency</span>
          
          <div className="relative my-4 flex items-center justify-center">
            {/* SVG circle meter */}
            <svg className="w-32 h-32" viewBox="0 0 100 100">
              <circle cx="50" cy="50" r="40" stroke="#1e293b" strokeWidth="8" fill="none" />
              <circle
                cx="50"
                cy="50"
                r="40"
                stroke="#5f56e5"
                strokeWidth="8"
                fill="none"
                strokeDasharray="251.2"
                strokeDashoffset={251.2 - (251.2 * scoreOverall) / 100}
                strokeLinecap="round"
                className="transition-all duration-1000"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-3xl font-extrabold tracking-tight">{scoreOverall}%</span>
              <span className="text-[10px] text-slate-300 font-bold">Grade</span>
            </div>
          </div>

          <span className="text-xs font-bold text-indigo-300 bg-indigo-500/10 border border-indigo-500/20 px-2.5 py-1 rounded-full">
            {scoreOverall >= 80 ? 'EXCELLENT' : scoreOverall >= 60 ? 'ELIGIBLE' : 'SUPPORT NEEDED'}
          </span>
        </div>

        {/* Technical Sub-Card */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 flex flex-col justify-between">
          <div className="space-y-1">
            <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Technical Capability</p>
            <h3 className="text-2xl font-extrabold text-slate-900 dark:text-white">{scoreTech}%</h3>
          </div>
          <div className="w-full bg-slate-100 dark:bg-slate-950 h-2 rounded-full my-3">
            <div className="bg-indigo-650 h-2 rounded-full" style={{ width: `${scoreTech}%` }}></div>
          </div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
            Measures correctness of domain theories, code rationale, and vocabulary.
          </p>
        </div>

        {/* Communication Sub-Card */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 flex flex-col justify-between">
          <div className="space-y-1">
            <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Communication Pacing</p>
            <h3 className="text-2xl font-extrabold text-slate-900 dark:text-white">{scoreComm}%</h3>
          </div>
          <div className="w-full bg-slate-100 dark:bg-slate-950 h-2 rounded-full my-3">
            <div className="bg-emerald-500 h-2 rounded-full" style={{ width: `${scoreComm}%` }}></div>
          </div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
            Measures clarity of speech transitions, paragraph structure, and fluency.
          </p>
        </div>

        {/* Confidence Sub-Card */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 flex flex-col justify-between">
          <div className="space-y-1">
            <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Structural Confidence</p>
            <h3 className="text-2xl font-extrabold text-slate-900 dark:text-white">{scoreConf}%</h3>
          </div>
          <div className="w-full bg-slate-100 dark:bg-slate-950 h-2 rounded-full my-3">
            <div className="bg-purple-650 h-2 rounded-full" style={{ width: `${scoreConf}%` }}></div>
          </div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
            Measures reaction speed under timers, detail depth, and delivery formatting.
          </p>
        </div>
      </div>

      {/* Strengths & Weaknesses analysis loops */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6" id="strengths-weaknesses-row">
        
        {/* Correct & Strengths areas */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-100 dark:border-slate-850 pb-3">
            <div className="bg-emerald-50 dark:bg-emerald-950/30 p-2 rounded-lg">
              <CheckCircle className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
            </div>
            <h4 className="font-bold text-slate-900 dark:text-white">Identified Core Strengths</h4>
          </div>

          <ul className="space-y-3 pl-1 text-sm text-slate-600 dark:text-slate-300">
            {result.strengths && result.strengths.length > 0 ? (
              result.strengths.map((st, i) => (
                <li key={i} className="flex gap-2 items-start leading-relaxed">
                  <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full mt-2 shrink-0"></span>
                  <span>{st}</span>
                </li>
              ))
            ) : (
              <li className="italic text-slate-400">Consistent phrasing logged across all evaluation sections.</li>
            )}
          </ul>
        </div>

        {/* Improvement & Weak areas */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-100 dark:border-slate-850 pb-3">
            <div className="bg-rose-50 dark:bg-rose-950/30 p-2 rounded-lg">
              <AlertTriangle className="w-5 h-5 text-rose-600 dark:text-rose-450" />
            </div>
            <h4 className="font-bold text-slate-900 dark:text-white">Gaps & Weak Areas</h4>
          </div>

          <ul className="space-y-3 pl-1 text-sm text-slate-605 dark:text-slate-300">
            {result.weaknesses && result.weaknesses.length > 0 ? (
              result.weaknesses.map((we, i) => (
                <li key={i} className="flex gap-2 items-start leading-relaxed">
                  <span className="w-1.5 h-1.5 bg-rose-550 rounded-full mt-2 shrink-0"></span>
                  <span>{we}</span>
                </li>
              ))
            ) : (
              <li className="italic text-slate-400">Excellent theoretical alignment with no glaring weaknesses logged.</li>
            )}
          </ul>
        </div>
      </div>

      {/* Smart Personalized Suggestions & Resource Links */}
      <div className="bg-gradient-to-r from-indigo-50/50 to-indigo-100/20 dark:from-indigo-950/20 dark:to-slate-900 border border-indigo-100 dark:border-indigo-950 p-6 rounded-2xl space-y-4">
        <div className="flex items-center gap-2 border-b border-indigo-100/60 dark:border-indigo-950 pb-3">
          <div className="bg-indigo-100 dark:bg-indigo-900/30 p-2 rounded-xl">
            <Lightbulb className="w-5 h-5 text-indigo-700 dark:text-indigo-400" />
          </div>
          <div>
            <h4 className="font-bold text-indigo-950 dark:text-indigo-305 text-base">Study Maps & Actionable Recommendations</h4>
            <p className="text-xs text-indigo-700/80 dark:text-slate-400">Custom curricula selected based on performance metrics</p>
          </div>
        </div>

        {/* Suggestion Bullet Points */}
        <div className="space-y-3.5 pt-1">
          {result.improvement_suggestions && result.improvement_suggestions.map((sug, i) => (
            <p key={i} className="text-sm text-slate-705 dark:text-slate-300 leading-relaxed flex items-start gap-2">
              <span className="text-indigo-650 font-bold shrink-0 mt-0.5">•</span>
              {sug}
            </p>
          ))}
        </div>

        {/* Learning Resources mapping list */}
        {result.recommended_resources && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t border-indigo-100/40 dark:border-indigo-950">
            {result.recommended_resources.map((resItem, i) => (
              <div key={i} className="bg-white dark:bg-slate-950 border border-indigo-100/30 dark:border-indigo-900/35 rounded-xl p-4 flex flex-col justify-between">
                <div className="space-y-1">
                  <span className="text-[10px] text-indigo-600 dark:text-indigo-400 font-black uppercase">Recommended Topic</span>
                  <p className="font-bold text-sm text-slate-950 dark:text-white">{resItem.topic}</p>
                  <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed pt-1">{resItem.description}</p>
                </div>
                <div className="pt-3 flex justify-between items-center text-xs">
                  <span className="text-slate-400 italic">Curriculum Partner</span>
                  <a
                    href="https://geeksforgeeks.org"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-0.5 cursor-pointer"
                  >
                    Go study
                    <ChevronRight className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Individual Question by Question details audits list */}
      <div className="border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 rounded-2xl p-6 space-y-6">
        <h4 className="text-lg font-black text-slate-900 dark:text-white pb-3 border-b border-slate-100 dark:border-slate-850">
          Interview Response Audits & Gradings ({interview.questions.length} Items)
        </h4>

        <div className="space-y-8 divide-y divide-slate-100 dark:divide-slate-800">
          {interview.questions.map((q, qidx) => (
            <div key={q.id} className={`pt-6 ${qidx === 0 ? 'pt-0' : ''} space-y-4`}>
              
              {/* Question header */}
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-2">
                <div className="space-y-0.5">
                  <span className="text-[10px] font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-widest bg-indigo-50 dark:bg-indigo-950/40 px-2 py-0.5 rounded border border-indigo-100/50 dark:border-indigo-900/20">
                    Question {qidx + 1} • {q.category}
                  </span>
                  <p className="font-extrabold text-sm md:text-base text-slate-900 dark:text-white pt-1">"{q.question}"</p>
                </div>

                {q.evaluation ? (
                  <span className="bg-indigo-600 text-white font-bold text-xs px-3 py-1.5 rounded-lg shrink-0">
                    Grade: {q.evaluation.score}/100
                  </span>
                ) : (
                  <span className="bg-slate-200 text-slate-600 font-semibold text-xs px-3 py-1.5 rounded-lg shrink-0">
                    Skipped / Ungraded
                  </span>
                )}
              </div>

              {/* Core Answer content comparisons */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                {/* Candidates Answer */}
                <div className="bg-slate-50 dark:bg-slate-950 rounded-xl p-4 border border-slate-150 dark:border-slate-850 space-y-1.5">
                  <span className="font-bold text-slate-400 block uppercase tracking-wider text-[10px]">Candidate Answer Text</span>
                  <p className="text-slate-700 dark:text-slate-300 whitespace-pre-wrap leading-relaxed italic">
                    "{q.userAnswer || 'No answer submitted.'}"
                  </p>
                  {q.timeTaken !== undefined && (
                    <span className="text-[10px] text-slate-500 font-bold block pt-2">
                      Response formulation: {q.timeTaken} seconds
                    </span>
                  )}
                </div>

                {/* Model Reference Answer */}
                <div className="bg-slate-50 dark:bg-slate-950 rounded-xl p-4 border border-slate-150 dark:border-slate-850 space-y-1.5">
                  <span className="font-bold text-indigo-400 block uppercase tracking-wider text-[10px]">Reference Sample Answer</span>
                  <p className="text-slate-700 dark:text-slate-350 leading-relaxed font-mono text-[11px]">
                    {q.sample_answer}
                  </p>
                  <div className="pt-2 flex flex-wrap gap-1 items-center">
                    <span className="text-[10px] font-bold text-slate-500 mr-1 flex items-center gap-0.5">
                      <Key className="w-3 h-3 text-indigo-500" /> Key tags:
                    </span>
                    {q.expected_keywords.map(kw => (
                      <span key={kw} className="bg-slate-200 dark:bg-slate-850 text-slate-700 dark:text-slate-300 px-1.5 py-0.5 rounded text-[9px] font-semibold">
                        {kw}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Grading evaluations summary */}
              {q.evaluation ? (
                <div className="bg-indigo-50/25 dark:bg-slate-950 border border-slate-150 dark:border-slate-850 rounded-xl p-4 space-y-3 text-xs leading-relaxed">
                  <div className="font-bold text-indigo-850 dark:text-indigo-400 text-xs border-b border-slate-100 dark:border-slate-850 pb-1.5">
                    Maya's Performance Commentary Analysis:
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <p><strong className="text-slate-700 dark:text-slate-300">Relevance:</strong> {q.evaluation.relevance}</p>
                      <p><strong className="text-slate-700 dark:text-slate-300">Technical Accuracy:</strong> {q.evaluation.technicalAccuracy}</p>
                      <p><strong className="text-slate-700 dark:text-slate-300">Completeness:</strong> {q.evaluation.completeness}</p>
                    </div>

                    <div className="space-y-1">
                      <p><strong className="text-slate-700 dark:text-slate-300">Grammar & Phrasing:</strong> {q.evaluation.grammar}</p>
                      <p><strong className="text-slate-700 dark:text-slate-300">Keywords covered:</strong> {q.evaluation.keywordCoverage ? `${q.evaluation.keywordCoverage.percentage}%` : 'N/A'}</p>
                    </div>
                  </div>
                </div>
              ) : null}

            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
