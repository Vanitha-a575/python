import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

// Load environment variables
dotenv.config();

import { 
  getDatabase, 
  saveDatabase 
} from "./src/dbSchema";
import { 
  hashPassword, 
  verifyPassword, 
  signJWT, 
  verifyJWT 
} from "./src/lib/auth";
import { AnswerEvaluation, Interview, Result, User, Question } from "./src/types";

// Setup Express
const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Gemini SDK with telemetry header per skill instructions
const geminiApiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;

if (geminiApiKey) {
  try {
    ai = new GoogleGenAI({
      apiKey: geminiApiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
    console.log("Initialized Gemini Client successfully.");
  } catch (err) {
    console.error("Failed to initialize Gemini API Client:", err);
  }
} else {
  console.log("No GEMINI_API_KEY found. Utilizing high-quality keyword fallback evaluation system.");
}

// Ensure database file gets initialized on start up
getDatabase();

// Authentication Middleware
function authenticateToken(req: any, res: any, next: any) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) return res.status(401).json({ error: "Access token missing" });

  const decoded = verifyJWT(token);
  if (!decoded) return res.status(403).json({ error: "Token is invalid, expired or corrupt" });

  req.user = decoded;
  next();
}

// Admin Check Middleware
function requireAdmin(req: any, res: any, next: any) {
  if (!req.user || !req.user.isAdmin) {
    return res.status(403).json({ error: "Administrator credentials required for this action" });
  }
  next();
}

// ==========================================
// AUTHENTICATION ENDPOINTS
// ==========================================

app.post("/api/auth/register", (req, res) => {
  const { name, email, password, confirmPassword } = req.body;

  if (!name || !email || !password || !confirmPassword) {
    return res.status(400).json({ error: "Please complete all registration fields" });
  }

  if (password !== confirmPassword) {
    return res.status(400).json({ error: "Passwords do not match" });
  }

  const db = getDatabase();
  const lowerEmail = email.toLowerCase().trim();

  // Test duplicate email
  const existingUser = db.users.find(u => u.email.toLowerCase() === lowerEmail);
  if (existingUser) {
    return res.status(400).json({ error: "This email is already registered" });
  }

  const newUser: User = {
    id: `u-${Date.now()}`,
    name: name.trim(),
    email: lowerEmail,
    password: hashPassword(password),
    isAdmin: false,
    profile_image: `https://images.unsplash.com/photo-${['1534528741775-53994a69daeb', '1539571696357-5a69c17a67c6', '1494790108377-be9c29b29330', '1507003211169-0a1dd7228f2d'][Math.floor(Math.random() * 4)]}?w=150`,
    created_at: new Date().toISOString()
  };

  db.users.push(newUser);
  saveDatabase(db);

  // Generate JWT token
  const token = signJWT({ id: newUser.id, email: newUser.email, isAdmin: newUser.isAdmin });
  
  res.status(201).json({
    message: "Registration successful!",
    token,
    user: {
      id: newUser.id,
      name: newUser.name,
      email: newUser.email,
      profile_image: newUser.profile_image,
      isAdmin: newUser.isAdmin,
      created_at: newUser.created_at
    }
  });
});

app.post("/api/auth/login", (req, res) => {
  const { email, password, rememberMe } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: "Please enter your email and password" });
  }

  const db = getDatabase();
  const user = db.users.find(u => u.email.toLowerCase() === email.toLowerCase().trim());

  if (!user || !user.password || !verifyPassword(password, user.password)) {
    return res.status(401).json({ error: "Invalid email or password credentials" });
  }

  const token = signJWT(
    { id: user.id, email: user.email, isAdmin: user.isAdmin },
    rememberMe ? 168 : 24 // 7 days if remember checked, else 24 hrs
  );

  res.json({
    message: "Login successful!",
    token,
    user: {
      id: user.id,
      name: user.name,
      email: user.email,
      profile_image: user.profile_image,
      isAdmin: user.isAdmin,
      created_at: user.created_at
    }
  });
});

app.get("/api/auth/session", authenticateToken, (req: any, res) => {
  const db = getDatabase();
  const user = db.users.find(u => u.id === req.user.id);

  if (!user) {
    return res.status(404).json({ error: "Session user not found" });
  }

  res.json({
    user: {
      id: user.id,
      name: user.name,
      email: user.email,
      profile_image: user.profile_image,
      isAdmin: user.isAdmin,
      created_at: user.created_at
    }
  });
});

// ==========================================
// USER DASHBOARD / STATISTICS
// ==========================================

app.get("/api/stats", authenticateToken, (req: any, res) => {
  const db = getDatabase();
  const userId = req.user.id;

  const userInterviews = db.interviews.filter(i => i.user_id === userId && i.status === "completed");
  const userResults = db.results.filter(r => r.user_id === userId);

  // Compute stats
  const totalWeight = userInterviews.length;
  const averageScore = totalWeight > 0 
    ? Math.round(userInterviews.reduce((acc, curr) => acc + curr.overall_score, 0) / totalWeight) 
    : 0;

  const bestScore = totalWeight > 0 
    ? Math.max(...userInterviews.map(i => i.overall_score)) 
    : 0;

  // Weakest category computation from completed evaluations
  let technicalSum = 0, technicalCount = 0;
  let hrSum = 0, hrCount = 0;
  let aptitudeSum = 0, aptitudeCount = 0;

  userInterviews.forEach(i => {
    i.questions.forEach(q => {
      if (q.evaluation) {
        if (q.category === "Technical") {
          technicalSum += q.evaluation.score;
          technicalCount++;
        } else if (q.category === "HR") {
          hrSum += q.evaluation.score;
          hrCount++;
        } else if (q.category === "Aptitude") {
          aptitudeSum += q.evaluation.score;
          aptitudeCount++;
        }
      }
    });
  });

  const avgTechnical = technicalCount > 0 ? Math.round(technicalSum / technicalCount) : 80;
  const avgHR = hrCount > 0 ? Math.round(hrSum / hrCount) : 85;
  const avgAptitude = aptitudeCount > 0 ? Math.round(aptitudeSum / aptitudeCount) : 75;

  let weakestCategory = "None";
  if (totalWeight > 0) {
    const categories = [
      { name: "Technical", val: avgTechnical },
      { name: "HR", val: avgHR },
      { name: "Aptitude", val: avgAptitude }
    ];
    categories.sort((a, b) => a.val - b.val);
    weakestCategory = categories[0].name;
  }

  // Dashboard Cards averages
  const overallTechAverage = userInterviews.length > 0
    ? Math.round(userInterviews.reduce((acc, curr) => acc + curr.technical_score, 0) / userInterviews.length)
    : 0;

  const overallCommAverage = userInterviews.length > 0
    ? Math.round(userInterviews.reduce((acc, curr) => acc + curr.communication_score, 0) / userInterviews.length)
    : 0;

  const overallConfAverage = userInterviews.length > 0
    ? Math.round(userInterviews.reduce((acc, curr) => acc + curr.confidence_score, 0) / userInterviews.length)
    : 0;

  // Recent Interview History list
  const recentHistory = userInterviews
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .slice(0, 10)
    .map(i => ({
      id: i.id,
      role: i.role,
      date: i.date,
      overall_score: i.overall_score,
      interview_type: i.interview_type,
      questions_count: i.questions.length
    }));

  // Progress trend chart computation (by month name)
  const monthMap: Record<string, { total: number, count: number }> = {};
  userInterviews.forEach(i => {
    const m = new Date(i.date).toLocaleDateString('default', { month: 'short', year: 'numeric' });
    if (!monthMap[m]) monthMap[m] = { total: 0, count: 0 };
    monthMap[m].total += i.overall_score;
    monthMap[m].count++;
  });

  const monthlyProgress = Object.keys(monthMap).map(m => ({
    month: m,
    score: Math.round(monthMap[m].total / monthMap[m].count),
    count: monthMap[m].count
  })).reverse();

  res.json({
    totalInterviews: totalWeight,
    averageScore,
    bestScore,
    weakestCategory,
    technicalScore: overallTechAverage,
    communicationScore: overallCommAverage,
    confidenceScore: overallConfAverage,
    recentHistory,
    categoryScores: {
      technical: avgTechnical,
      hr: avgHR,
      aptitude: avgAptitude
    },
    monthlyProgress
  });
});

// ==========================================
// INTERVIEW FLOW MODULES
// ==========================================

// 1. Start a practice interview session
app.post("/api/interviews/start", authenticateToken, (req: any, res) => {
  const { role, interview_type, difficulty, questionCount, timer, mode } = req.body;

  if (!role || !interview_type || !difficulty || !questionCount || !timer || !mode) {
    return res.status(400).json({ error: "Missing interview start configurations" });
  }

  const db = getDatabase();

  // Find questions matching conditions
  // Split pool based on type
  let mathClassQuestions: Question[] = [];

  if (interview_type === "Technical") {
    // Only category Technical for selected Role
    mathClassQuestions = db.questions.filter(q => q.category === "Technical" && q.role === role);
  } else if (interview_type === "HR") {
    // Only HR questions
    mathClassQuestions = db.questions.filter(q => q.category === "HR");
  } else {
    // Mock Placement: Mixed of Technical (for role), HR, and Aptitude
    const roleTech = db.questions.filter(q => q.category === "Technical" && q.role === role);
    const hrs = db.questions.filter(q => q.category === "HR");
    const apts = db.questions.filter(q => q.category === "Aptitude");

    mathClassQuestions = [...roleTech, ...hrs, ...apts];
  }

  // Fallback to absolute anything if matching sets are small
  if (mathClassQuestions.length === 0) {
    mathClassQuestions = db.questions.slice(0, 20);
  }

  // Filter out difficulty levels matches, with fallbacks
  let matches = mathClassQuestions.filter(q => q.difficulty === difficulty);
  if (matches.length === 0) {
    matches = mathClassQuestions;
  }

  // Select random set
  const shuffled = [...matches].sort(() => 0.5 - Math.random());
  const selectedQuestions = shuffled.slice(0, parseInt(questionCount));

  const newInterview: Interview = {
    id: `i-${Date.now()}`,
    user_id: req.user.id,
    role,
    interview_type,
    difficulty,
    date: new Date().toISOString(),
    overall_score: 0,
    technical_score: 0,
    communication_score: 0,
    confidence_score: 0,
    time_settings: parseInt(timer),
    mode,
    questions: selectedQuestions.map(q => ({
      ...q,
      userAnswer: "",
      timeTaken: 0
    })),
    status: 'in_progress'
  };

  db.interviews.push(newInterview);
  saveDatabase(db);

  res.status(201).json({
    message: "Interview session created",
    interview: {
      id: newInterview.id,
      role: newInterview.role,
      interview_type: newInterview.interview_type,
      difficulty: newInterview.difficulty,
      questions_count: newInterview.questions.length,
      time_settings: newInterview.time_settings,
      mode: newInterview.mode,
      questions: newInterview.questions.map(q => ({
        id: q.id,
        category: q.category,
        question: q.question,
        difficulty: q.difficulty
      }))
    }
  });
});

// Helper feedback generator when Gemini is unconfigured or offline
function generateLocalEvaluationFallback(
  role: string,
  category: string,
  difficulty: string,
  questionText: string,
  expectedKeywords: string[],
  userAnswer: string,
  timeTaken: number,
  mode: string
): AnswerEvaluation {
  const ansLower = userAnswer.toLowerCase();
  
  // Tag coverage testing
  const covered: string[] = [];
  const missed: string[] = [];

  expectedKeywords.forEach(tag => {
    if (ansLower.includes(tag.toLowerCase())) {
      covered.push(tag);
    } else {
      missed.push(tag);
    }
  });

  const kwPercentage = expectedKeywords.length > 0 
    ? Math.round((covered.length / expectedKeywords.length) * 100)
    : 100;

  // Length calculation
  const wordCount = userAnswer.trim().split(/\s+/).length;
  
  // Score calculations
  let baseTechScore = 50 + (kwPercentage * 0.4);
  if (wordCount > 30) baseTechScore += 10;
  if (wordCount > 60) baseTechScore += 10;
  const technical_score = Math.min(100, Math.max(20, Math.round(baseTechScore)));

  // Communication scoring details
  let commScore = 60;
  if (wordCount > 40) commScore += 15;
  if (wordCount > 80) commScore += 15;
  if (timeTaken > 15) commScore += 10;
  const communication_score = Math.min(100, Math.max(30, Math.round(commScore)));

  // Confidence calculations based on pacing and length
  let confScore = 55;
  if (wordCount > 50) confScore += 15;
  if (timeTaken > 20 && timeTaken < 120) confScore += 15;
  if (mode === "voice") confScore += 10; // extra point booster for talking
  const confidence_score = Math.min(100, Math.max(25, Math.round(confScore)));

  const overall_score = Math.round((technical_score * 0.5) + (communication_score * 0.3) + (confidence_score * 0.2));

  // Personalized bullet lists
  const strengths: string[] = [];
  const weaknesses: string[] = [];
  const suggestions: string[] = [];

  if (kwPercentage > 60) {
    strengths.push(`Strong vocabulary coverage including: ${covered.slice(0, 3).join(', ')}.`);
  } else {
    weaknesses.push(`Requires broader coverage of key domain definitions like: ${missed.slice(0, 2).join(', ')}.`);
  }

  if (wordCount > 40) {
    strengths.push("Comprehensive elaboration showing strong structural articulation.");
  } else {
    weaknesses.push("Explanation is brief; detail should be expanded with examples.");
    suggestions.push("Focus on explaining 'why' first, then follow up with real-world design examples.");
  }

  if (timeTaken < 10 && wordCount > 5) {
    strengths.push("Extremely fast mental processing and answer formulation.");
  } else if (timeTaken > 90) {
    weaknesses.push("Response time was long. Candidates should aim to be more concise under timers.");
    suggestions.push("Prioritize structuring your answers into clear bullet points: definition -> utility -> example.");
  }

  if (category === "Technical") {
    suggestions.push(`Review practical applications of ${questionText.substring(0, 30)}...`);
    suggestions.push("Incorporate detailed code blocks or architecture flow diagrams during coding round sessions.");
  } else if (category === "HR") {
    suggestions.push("Structure behavioral questions using the STAR framework (Situation, Task, Action, Result).");
  } else {
    suggestions.push("Practice regular numerical drills to boost algorithmic solving speeds.");
  }

  return {
    score: overall_score,
    technical_score,
    communication_score,
    confidence_score,
    relevance: kwPercentage > 30 ? "Direct and relevant presentation addressing core query targets." : "Lacks alignment, answer drifts off query boundaries.",
    technicalAccuracy: `Verified keywords coverage at ${kwPercentage}%: ${covered.length} of ${expectedKeywords.length} tags accounted for.`,
    completeness: wordCount > 40 ? "Excellent coverage." : "Incomplete scope, needs more depth.",
    communicationQuality: wordCount > 30 ? "Good vocabulary and structured response flow." : "Too brief, lacks connecting thoughts.",
    grammar: "Pristine phrasing with clean technical descriptions.",
    keywordCoverage: {
      covered,
      missed,
      percentage: kwPercentage
    },
    strengths,
    weaknesses,
    suggestions
  };
}

// 2. Evaluate answer in real time using Gemini API (with in-house keyword fallback!)
app.post("/api/interviews/evaluate", authenticateToken, async (req: any, res) => {
  const { interviewId, questionId, userAnswer, timeTaken } = req.body;

  if (!interviewId || !questionId || userAnswer === undefined) {
    return res.status(400).json({ error: "Missing evaluation inputs" });
  }

  const db = getDatabase();
  const interview = db.interviews.find(i => i.id === interviewId && i.user_id === req.user.id);
  
  if (!interview) {
    return res.status(404).json({ error: "Interview record not found" });
  }

  // Find the exact question in the interview instance
  const questionIndex = interview.questions.findIndex(q => q.id === questionId);
  if (questionIndex === -1) {
    return res.status(404).json({ error: "Question not found in interview" });
  }

  const question = interview.questions[questionIndex];

  // If Gemini client is active, request structured feedback
  if (ai) {
    try {
      console.log(`Evaluating question ID ${questionId} with Gemini Gemini 3.5 Flash Model...`);
      const prompt = `
        You are an expert technical and HR interviewer evaluating placement candidates.
        Evaluate the student's answer and produce detailed structured feedback.

        Context:
        Role Target: ${interview.role}
        Category: ${question.category}
        Difficulty: ${question.difficulty}
        Question Asked: "${question.question}"
        Reference Expected Keywords: ${JSON.stringify(question.expected_keywords)}
        Sample Expected Answer Guide: "${question.sample_answer}"

        Candidate's Actual Answer: "${userAnswer}"
        Time Taken by candidate: ${timeTaken} seconds
        Response Mode: ${interview.mode} (voice or text transcription)

        Please return a strictly valid JSON response that matches this schema layout:
        {
          "score": (Overall score 0-100 based on technical layout, accuracy, completeness, and clarity),
          "technical_score": (0-100 specifically for relevance, accuracy, and completeness),
          "communication_score": (0-100 for grammar, pacing, and vocabulary clarity),
          "confidence_score": (0-100 calculated recursively combining response length, time efficiency, and delivery mode),
          "relevance": "Brief paragraph describing how directly the answer addresses the question.",
          "technicalAccuracy": "Brief technical analysis of their arguments alongside keywords.",
          "completeness": "Whether the explanation covers all required concepts or missing components.",
          "communicationQuality": "Feedback on terminology, vocabulary, and paragraph pacing.",
          "grammar": "Evaluation of spelling, syntax, or phrasing errors.",
          "keywordCoverage": {
            "covered": ["array of covered keywords from reference"],
            "missed": ["array of missed expected keywords"],
            "percentage": (percentage covered)
          },
          "strengths": ["at least 2 specific strengths in candidate's response"],
          "weaknesses": ["at least 2 specific weaknesses or omissions"],
          "suggestions": ["at least 2 clear, actionable recommendations for candidate preparation"]
        }
      `;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          temperature: 0.2
        },
      });

      const rawJson = response.text?.trim() || "";
      const evaluation: AnswerEvaluation = JSON.parse(rawJson);

      // Save to server database state
      interview.questions[questionIndex].userAnswer = userAnswer;
      interview.questions[questionIndex].timeTaken = parseInt(timeTaken);
      interview.questions[questionIndex].evaluation = evaluation;
      saveDatabase(db);

      return res.status(200).json({ evaluation });

    } catch (apiErr) {
      console.error("Gemini API threw an exception, invoking local keyword fallback parser:", apiErr);
      // Fallback
    }
  }

  // Pure Local Evaluator Fallback invocation
  const evaluation = generateLocalEvaluationFallback(
    interview.role,
    question.category,
    question.difficulty,
    question.question,
    question.expected_keywords,
    userAnswer,
    parseInt(timeTaken),
    interview.mode
  );

  interview.questions[questionIndex].userAnswer = userAnswer;
  interview.questions[questionIndex].timeTaken = parseInt(timeTaken);
  interview.questions[questionIndex].evaluation = evaluation;
  saveDatabase(db);

  res.status(200).json({ evaluation });
});

// 3. Complete and compile full interview results
app.post("/api/interviews/complete", authenticateToken, (req: any, res) => {
  const { interviewId } = req.body;

  if (!interviewId) {
    return res.status(400).json({ error: "Missing interview session identification token" });
  }

  const db = getDatabase();
  const index = db.interviews.findIndex(i => i.id === interviewId && i.user_id === req.user.id);

  if (index === -1) {
    return res.status(404).json({ error: "Interview session not found" });
  }

  const interview = db.interviews[index];
  interview.status = "completed";

  // Calculate cumulative average score tallies
  let totalOverall = 0, totalTech = 0, totalComm = 0, totalConf = 0;
  let evaluatedQuestionsCount = 0;

  const strengthsAccum: string[] = [];
  const weaknessesAccum: string[] = [];
  const suggestionsAccum: string[] = [];

  interview.questions.forEach(q => {
    if (q.evaluation) {
      evaluatedQuestionsCount++;
      totalOverall += q.evaluation.score;
      totalTech += q.evaluation.technical_score;
      totalComm += q.evaluation.communication_score;
      totalConf += q.evaluation.confidence_score;

      // Extract details
      strengthsAccum.push(...q.evaluation.strengths);
      weaknessesAccum.push(...q.evaluation.weaknesses);
      suggestionsAccum.push(...q.evaluation.suggestions);
    }
  });

  const finalOverall = evaluatedQuestionsCount > 0 ? Math.round(totalOverall / evaluatedQuestionsCount) : 0;
  const finalTech = evaluatedQuestionsCount > 0 ? Math.round(totalTech / evaluatedQuestionsCount) : 0;
  const finalComm = evaluatedQuestionsCount > 0 ? Math.round(totalComm / evaluatedQuestionsCount) : 0;
  const finalConf = evaluatedQuestionsCount > 0 ? Math.round(totalConf / evaluatedQuestionsCount) : 0;

  interview.overall_score = finalOverall;
  interview.technical_score = finalTech;
  interview.communication_score = finalComm;
  interview.confidence_score = finalConf;

  // Uniquify recommendations bullet points
  const distinctStrengths = Array.from(new Set(strengthsAccum)).slice(0, 4);
  const distinctWeaknesses = Array.from(new Set(weaknessesAccum)).slice(0, 4);
  const distinctSuggestions = Array.from(new Set(suggestionsAccum)).slice(0, 4);

  // Generate recommended educational track based on weak subjects
  const recommended_resources = [
    {
      topic: `${interview.role} Core Mechanics`,
      description: `Comprehensive training on advanced conceptual loops, scalability, and design structures in ${interview.role}.`,
      resource: "GeeksforGeeks placement training courses"
    },
    {
      topic: "Effective Speaking and Star Response Framing",
      description: "Learn to structure and deliver HR and technical responses with poise under strict interview timers.",
      resource: "Coursera Professional Communication Skills"
    }
  ];

  // Create new Result record
  const newResult: Result = {
    id: `r-${interview.id}`,
    user_id: req.user.id,
    interview_id: interview.id,
    role: interview.role,
    interview_type: interview.interview_type,
    date: interview.date,
    technical_score: finalTech,
    communication_score: finalComm,
    confidence_score: finalConf,
    overall_score: finalOverall,
    strengths: distinctStrengths.length > 0 ? distinctStrengths : ["Consistent communication pacing", "Direct alignment with questions asked."],
    weaknesses: distinctWeaknesses.length > 0 ? distinctWeaknesses : ["Brief elaboration on advanced edge cases", "Occasional pacing variance under strict countdown timers."],
    improvement_suggestions: distinctSuggestions.length > 0 ? distinctSuggestions : ["Incorporate specific industry models or SOLID theory into technical feedback", "Practice behavioral drills using the STAR technique."],
    recommended_resources
  };

  db.results.push(newResult);
  saveDatabase(db);

  res.json({
    message: "Interview finalized! Statistics compile successfully.",
    result: newResult
  });
});

// View all historical report cards
app.get("/api/results", authenticateToken, (req: any, res) => {
  const db = getDatabase();
  const userResults = db.results
    .filter(r => r.user_id === req.user.id)
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  res.json({ results: userResults });
});

// Download/Get specific complete interview result details
app.get("/api/results/:id", authenticateToken, (req: any, res) => {
  const db = getDatabase();
  const result = db.results.find(r => r.id === req.params.id && r.user_id === req.user.id);
  const interview = db.interviews.find(i => `r-${i.id}` === req.params.id && i.user_id === req.user.id);

  if (!result || !interview) {
    return res.status(404).json({ error: "Detailed interview report could not be found" });
  }

  res.json({ result, interview });
});

// ==========================================
// PROFILE MANAGEMENT ENDPOINTS
// ==========================================

app.put("/api/profile/update", authenticateToken, (req: any, res) => {
  const { name, profile_image } = req.body;

  if (!name) {
    return res.status(400).json({ error: "Name field is required" });
  }

  const db = getDatabase();
  const userIndex = db.users.findIndex(u => u.id === req.user.id);

  if (userIndex === -1) {
    return res.status(404).json({ error: "User profile not found" });
  }

  db.users[userIndex].name = name.trim();
  if (profile_image) {
    db.users[userIndex].profile_image = profile_image;
  }

  saveDatabase(db);

  res.json({
    message: "Profile updated successfully!",
    user: {
      id: db.users[userIndex].id,
      name: db.users[userIndex].name,
      email: db.users[userIndex].email,
      profile_image: db.users[userIndex].profile_image,
      isAdmin: db.users[userIndex].isAdmin,
      created_at: db.users[userIndex].created_at
    }
  });
});

app.put("/api/profile/password", authenticateToken, (req: any, res) => {
  const { currentPassword, newPassword, confirmNewPassword } = req.body;

  if (!currentPassword || !newPassword || !confirmNewPassword) {
    return res.status(400).json({ error: "Please fill in all security fields" });
  }

  if (newPassword !== confirmNewPassword) {
    return res.status(400).json({ error: "Confirm password does not match with new password" });
  }

  const db = getDatabase();
  const userIndex = db.users.findIndex(u => u.id === req.user.id);

  if (userIndex === -1) {
    return res.status(404).json({ error: "User profile not found" });
  }

  const user = db.users[userIndex];

  if (!user.password || !verifyPassword(currentPassword, user.password)) {
    return res.status(401).json({ error: "Current password typed is incorrect" });
  }

  db.users[userIndex].password = hashPassword(newPassword);
  saveDatabase(db);

  res.json({ message: "Password updated successfully!" });
});


// ==========================================
// ADMIN WORKFLOW ENDPOINTS (FULLY SECURED!)
// ==========================================

// 1. Get Site metrics and statistics
app.get("/api/admin/stats", authenticateToken, requireAdmin, (req, res) => {
  const db = getDatabase();

  const totalUsers = db.users.filter(u => !u.isAdmin).length;
  const totalQuestions = db.questions.length;
  const totalInterviews = db.interviews.filter(i => i.status === "completed").length;

  let overallScoreSum = 0;
  const completedInterviews = db.interviews.filter(i => i.status === "completed");
  
  completedInterviews.forEach(i => {
    overallScoreSum += i.overall_score;
  });

  const averageOverallScore = completedInterviews.length > 0 
    ? Math.round(overallScoreSum / completedInterviews.length) 
    : 0;

  // Key Roles distribution
  const roleBreakdown: Record<string, number> = {};
  db.questions.forEach(q => {
    if (q.category === "Technical") {
      roleBreakdown[q.role] = (roleBreakdown[q.role] || 0) + 1;
    }
  });

  // Category distribution
  const categoryBreakdown: Record<string, number> = {};
  db.questions.forEach(q => {
    categoryBreakdown[q.category] = (categoryBreakdown[q.category] || 0) + 1;
  });

  // Recent Interview histories across site
  const recentInterviews = db.interviews
    .filter(i => i.status === "completed")
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .slice(0, 15)
    .map(i => {
      const u = db.users.find(user => user.id === i.user_id);
      return {
        id: i.id,
        userName: u ? u.name : "Deleted user",
        userEmail: u ? u.email : "Undefined email",
        role: i.role,
        date: i.date,
        score: i.overall_score
      };
    });

  res.json({
    totalUsers,
    totalQuestions,
    totalInterviews,
    averageOverallScore,
    roleBreakdown,
    categoryBreakdown,
    recentInterviews
  });
});

// 2. Questions full list
app.get("/api/admin/questions", authenticateToken, requireAdmin, (req, res) => {
  const db = getDatabase();
  res.json({ questions: db.questions.reverse() });
});

// 3. Create question
app.post("/api/admin/questions", authenticateToken, requireAdmin, (req, res) => {
  const { role, category, difficulty, question, expected_keywords, sample_answer } = req.body;

  if (!role || !category || !difficulty || !question || !expected_keywords || !sample_answer) {
    return res.status(400).json({ error: "All question attributes are required" });
  }

  const db = getDatabase();
  const listKeywords = Array.isArray(expected_keywords) 
    ? expected_keywords 
    : String(expected_keywords).split(",").map(k => k.trim()).filter(Boolean);

  const newQ: Question = {
    id: `q-${Date.now()}`,
    role,
    category,
    difficulty,
    question: question.trim(),
    expected_keywords: listKeywords,
    sample_answer: sample_answer.trim()
  };

  db.questions.push(newQ);
  saveDatabase(db);

  res.status(201).json({ message: "New custom question added successfully!", question: newQ });
});

// 4. Edit question
app.put("/api/admin/questions/:id", authenticateToken, requireAdmin, (req, res) => {
  const { role, category, difficulty, question, expected_keywords, sample_answer } = req.body;
  const qId = req.params.id;

  const db = getDatabase();
  const qIdx = db.questions.findIndex(q => q.id === qId);

  if (qIdx === -1) {
    return res.status(404).json({ error: "Questions target key could not be resolved" });
  }

  const listKeywords = Array.isArray(expected_keywords) 
    ? expected_keywords 
    : String(expected_keywords).split(",").map(k => k.trim()).filter(Boolean);

  db.questions[qIdx] = {
    ...db.questions[qIdx],
    role: role || db.questions[qIdx].role,
    category: category || db.questions[qIdx].category,
    difficulty: difficulty || db.questions[qIdx].difficulty,
    question: question ? question.trim() : db.questions[qIdx].question,
    expected_keywords: listKeywords || db.questions[qIdx].expected_keywords,
    sample_answer: sample_answer ? sample_answer.trim() : db.questions[qIdx].sample_answer
  };

  saveDatabase(db);
  res.json({ message: "Question content updated successfully!", question: db.questions[qIdx] });
});

// 5. Delete Question
app.delete("/api/admin/questions/:id", authenticateToken, requireAdmin, (req, res) => {
  const db = getDatabase();
  const qIdx = db.questions.findIndex(q => q.id === req.params.id);

  if (qIdx === -1) {
    return res.status(404).json({ error: "Questions target key could not be found" });
  }

  db.questions.splice(qIdx, 1);
  saveDatabase(db);

  res.json({ message: "Question deleted successfully!" });
});

// 6. View all registered users
app.get("/api/admin/users", authenticateToken, requireAdmin, (req, res) => {
  const db = getDatabase();
  const clients = db.users.map(u => ({
    id: u.id,
    name: u.name,
    email: u.email,
    isAdmin: !!u.isAdmin,
    created_at: u.created_at,
    profile_image: u.profile_image
  }));

  res.json({ users: clients });
});


// ==========================================
// VITE INTEGRATION / SPA FALLBACK
// ==========================================

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // Serve production static assets safely from inside dist
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  // Fallback catch-all for developments index.html targeting
  app.get("*", (req, res, next) => {
    if (process.env.NODE_ENV !== "production") {
      res.sendFile(path.join(process.cwd(), "index.html"));
    } else {
      next();
    }
  });

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`AI Interview Prep server is listening on port: ${PORT}`);
  });
}

startServer();
